<?php

declare(strict_types=1);

session_start();

require_once dirname(__DIR__) . '/config/database.php';
require_once dirname(__DIR__) . '/includes/funciones.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: ../registro-visita.php');
    exit;
}

$matricula = trim((string) ($_POST['matricula'] ?? ''));
$actividades = $_POST['actividades'] ?? [];

if ($matricula === '' || !is_array($actividades) || count($actividades) === 0) {
    $_SESSION['error'] = 'Selecciona un visitante y al menos una actividad.';
    header('Location: ../registro-visita.php');
    exit;
}

$ids = array_values(array_unique(array_map('intval', $actividades)));
$ids = array_filter($ids, static fn (int $id) => $id > 0);

if (count($ids) === 0) {
    $_SESSION['error'] = 'Actividades no válidas.';
    header('Location: ../registro-visita.php');
    exit;
}

try {
    $pdo = db();

    $check = $pdo->prepare('SELECT matricula FROM usuario WHERE matricula = :m');
    $check->execute([':m' => $matricula]);
    if (!$check->fetch()) {
        throw new RuntimeException(
            'No existe un usuario con esa matrícula. Regístralo primero en la tabla usuario.'
        );
    }

    $placeholders = implode(',', array_fill(0, count($ids), '?'));
    $stmtVal = $pdo->prepare(
        "SELECT id_actividad FROM actividad WHERE id_actividad IN ($placeholders)"
    );
    $stmtVal->execute($ids);
    $validos = array_column($stmtVal->fetchAll(), 'id_actividad', 'id_actividad');
    $ids = array_values(array_intersect($ids, array_map('intval', array_keys($validos))));

    if (count($ids) === 0) {
        throw new RuntimeException('Ninguna actividad seleccionada existe en la base de datos.');
    }

    $pdo->beginTransaction();

    $insert = $pdo->prepare(
        'INSERT INTO visita_registro (matricula, id_actividad, fecha_hora)
         VALUES (:m, :a, NOW())'
    );

    foreach ($ids as $idActividad) {
        $insert->execute([
            ':m' => $matricula,
            ':a' => $idActividad,
        ]);
    }

    $pdo->commit();

    header('Location: ../registro-visita.php?exito=1&matricula=' . urlencode($matricula));
    exit;
} catch (Throwable $e) {
    if (isset($pdo) && $pdo->inTransaction()) {
        $pdo->rollBack();
    }
    $_SESSION['error'] = 'Error al guardar: ' . $e->getMessage();
    header('Location: ../registro-visita.php');
    exit;
}
