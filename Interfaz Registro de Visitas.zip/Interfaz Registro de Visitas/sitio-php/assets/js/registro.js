(function () {
  const input = document.getElementById('busqueda-input');
  const dropdown = document.getElementById('dropdown');
  const box = document.getElementById('busqueda-box');
  const btnLimpiar = document.getElementById('btn-limpiar');
  const hint = document.getElementById('hint-vacio');
  const panel = document.getElementById('panel-registro');
  const tarjeta = document.getElementById('tarjeta-usuario');
  const matriculaInput = document.getElementById('matricula');
  const btnRegistrar = document.getElementById('btn-registrar');
  const reloj = document.getElementById('reloj');
  const horaRegistro = document.getElementById('hora-registro');

  if (!input) return;

  let usuarioActual = null;
  let timer = null;

  function actualizarReloj() {
    const now = new Date();
    const h = String(now.getHours()).padStart(2, '0');
    const m = String(now.getMinutes()).padStart(2, '0');
    const txt = `${h}:${m}`;
    if (reloj) reloj.textContent = txt;
    if (horaRegistro) horaRegistro.textContent = txt;
  }
  actualizarReloj();
  setInterval(actualizarReloj, 1000);

  function colorTipo(tipo) {
    if (tipo === 'Docente') return { bg: '#4198C6', text: '#fff' };
    if (tipo === 'Externo') return { bg: '#F97316', text: '#fff' };
    return { bg: '#16a34a', text: '#fff' };
  }

  function esc(texto) {
    const d = document.createElement('div');
    d.textContent = texto ?? '';
    return d.innerHTML;
  }

  function cerrarDropdown() {
    dropdown.classList.remove('open');
  }

  function limpiarTodo() {
    usuarioActual = null;
    input.value = '';
    matriculaInput.value = '';
    panel.classList.add('hidden');
    btnLimpiar.classList.add('hidden');
    hint.classList.remove('hidden');
    cerrarDropdown();
    document.querySelectorAll('.actividad-btn').forEach((b) => {
      b.classList.remove('selected');
      const cb = b.querySelector('input');
      if (cb) cb.checked = false;
      resetEstiloActividad(b);
    });
    validarFormulario();
    input.focus();
  }

  function resetEstiloActividad(btn) {
    const wrap = btn.querySelector('.act-icon-wrap');
    const icon = btn.querySelector('.fa-solid');
    const label = btn.querySelector('.act-label');
    if (wrap) wrap.style.background = 'rgba(65,152,198,.1)';
    if (icon) icon.style.color = '#4198C6';
    if (label) label.style.color = '#374151';
  }

  btnLimpiar?.addEventListener('click', limpiarTodo);

  input.addEventListener('input', () => {
    const q = input.value.trim();
    btnLimpiar.classList.toggle('hidden', q.length === 0);
    if (usuarioActual) {
      usuarioActual = null;
      panel.classList.add('hidden');
    }

    if (q.length < 2) {
      cerrarDropdown();
      hint.classList.remove('hidden');
      return;
    }

    hint.classList.add('hidden');
    clearTimeout(timer);
    timer = setTimeout(() => buscar(q), 250);
  });

  input.addEventListener('focus', () => {
    box.classList.add('focus');
    if (dropdown.children.length) dropdown.classList.add('open');
  });

  input.addEventListener('blur', () => {
    box.classList.remove('focus');
    setTimeout(cerrarDropdown, 200);
  });

  async function buscar(q) {
    try {
      const res = await fetch(`api/buscar.php?q=${encodeURIComponent(q)}`);
      const data = await res.json();
      renderDropdown(data);
    } catch (e) {
      dropdown.innerHTML =
        '<div style="padding:1rem;color:#ef4444;">Error al conectar con el servidor</div>';
      dropdown.classList.add('open');
    }
  }

  function renderDropdown(lista) {
    dropdown.innerHTML = '';
    if (!lista.length) {
      dropdown.innerHTML =
        '<' + 'div style="padding:1.5rem;text-align:center;color:#9ca3af;"><i class="fa-solid fa-user" style="font-size:2rem;opacity:.4;display:block;margin-bottom:.5rem;"></i>No se encontraron usuarios</div>';
    } else {
      lista.forEach((u) => {
        const btn = document.createElement('button');
        btn.type = 'button';
        btn.className = 'dropdown-item';
        const c = colorTipo(u.tipo);
        const programa = u.programa || 'Sin programa';
        btn.innerHTML = `
          <div class="avatar-sm">${esc(u.iniciales)}</div>
          <div style="flex:1;min-width:0;">
            <p style="font-weight:600;color:#1f2937;">${esc(u.nombre)}</p>
            <p style="font-size:.75rem;color:#9ca3af;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">${esc(u.matricula)} · ${esc(programa)}</p>
          </div>
          <span class="badge-tipo" style="background:${c.bg};color:${c.text}">${esc(u.tipo)}</span>
        `;
        btn.addEventListener('click', () => seleccionarUsuario(u));
        dropdown.appendChild(btn);
      });
    }
    dropdown.classList.add('open');
  }

  function seleccionarUsuario(u) {
    usuarioActual = u;
    input.value = u.nombre;
    matriculaInput.value = u.matricula;
    cerrarDropdown();
    hint.classList.add('hidden');
    panel.classList.remove('hidden');
    btnLimpiar.classList.remove('hidden');

    const c = colorTipo(u.tipo);
    tarjeta.innerHTML = `
      <div style="display:flex;gap:1.25rem;align-items:flex-start;">
        <div style="width:4rem;height:4rem;border-radius:1rem;background:linear-gradient(135deg,#F97316,#e8620a);display:flex;align-items:center;justify-content:center;color:#fff;font-size:1.25rem;font-weight:700;">
          ${esc(u.iniciales)}
        </div>
        <div style="flex:1;">
          <div style="display:flex;align-items:center;gap:.75rem;flex-wrap:wrap;margin-bottom:.5rem;">
            <h3 style="color:#fff;font-size:1.2rem;font-weight:700;">${esc(u.nombre)}</h3>
            <span class="badge-tipo" style="background:${c.bg};color:${c.text}">${esc(u.tipo)}</span>
          </div>
          <div style="display:grid;grid-template-columns:1fr 1fr;gap:.35rem .75rem;font-size:.75rem;color:rgba(255,255,255,.7);">
            <div><i class="fa-solid fa-id-card" style="color:#4198C6;margin-right:.35rem;"></i>${esc(u.matricula)}</div>
            ${u.grado ? `<div><i class="fa-solid fa-graduation-cap" style="color:#4198C6;margin-right:.35rem;"></i>Grado ${esc(u.grado)}</div>` : ''}
            <div style="overflow:hidden;text-overflow:ellipsis;"><i class="fa-solid fa-envelope" style="color:#4198C6;margin-right:.35rem;"></i>${esc(u.correo || '—')}</div>
            <div><i class="fa-solid fa-book" style="color:#4198C6;margin-right:.35rem;"></i>${esc(u.programa || '—')}</div>
          </div>
        </div>
      </div>
    `;
    validarFormulario();
  }

  document.querySelectorAll('.actividad-btn').forEach((btn) => {
    btn.addEventListener('click', (e) => {
      if (e.target.tagName === 'INPUT') return;
      const cb = btn.querySelector('input');
      cb.checked = !cb.checked;
      btn.classList.toggle('selected', cb.checked);
      const icon = btn.querySelector('.fa-solid');
      const label = btn.querySelector('.act-label');
      const wrap = btn.querySelector('.act-icon-wrap');
      if (cb.checked) {
        if (wrap) wrap.style.background = 'rgba(255,255,255,.2)';
        if (icon) icon.style.color = '#fff';
        if (label) label.style.color = '#fff';
      } else {
        resetEstiloActividad(btn);
      }
      validarFormulario();
    });
  });

  function validarFormulario() {
    const n = document.querySelectorAll('input[name="actividades[]"]:checked').length;
    const ok = usuarioActual && n > 0;
    btnRegistrar.disabled = !ok;
    btnRegistrar.textContent = ok
      ? 'Confirmar Registro de Visita'
      : 'Selecciona al menos una actividad';
  }
})();
