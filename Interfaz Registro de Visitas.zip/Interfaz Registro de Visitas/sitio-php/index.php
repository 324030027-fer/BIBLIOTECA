<?php

declare(strict_types=1);

require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/includes/funciones.php';

$stats = [
    'titulos' => 0,
    'copias' => 0,
    'usuarios' => 0,
    'visitas_mes' => 0,
    'fuente_libros' => 'libros_prueba',
];
$dbOk = true;
$dbError = '';

try {
    $stats = estadisticas_inicio(db());
} catch (Throwable $e) {
    $dbOk = false;
    $dbError = $e->getMessage();
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sistema de Registro de Visitas · UPJR</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="assets/css/estilos.css">
</head>
<body class="page-inicio">
    <header class="header-inicio">
        <div class="header-inner">
            <div class="logos-row">
                <div class="logo-Edu"><img src="assets/logo_edu.png" alt="logoBiblioteca"></div>
            </div>
            <div class="header-center">
                <div class="logo-img"><img src="assets/universidad.png" alt="logoUPJR"></div>
            </div>
            <div class="header-right">
                <div class="logo-Bib"><img src="assets/LogoBiblioteca.png" alt="logoBiblioteca"></div>
            </div>
        </div>
    </header>

    <main class="hero">
        <div class="hero-overlay"></div>
        <div class="hero-content">
            <div class="hero-icon"><i class="fa-solid fa-book-open"></i></<?= 'div' ?>>
            <h1>Sistema de Registro<span>de Visitas</span></h1>
            <div class="hero-bar"></div>
            <p>Biblioteca Central · Universidad Politécnica de Juventino Rosas</p>
            <p class="small">Consulta el acervo bibliográfico y registra las actividades de cada visita.</p>

            <?php if (!$dbOk): ?>
                <p class="alert-db">
                    No hay conexión a MySQL (<code>biblioteca_upjr</code>). Revisa <code>config/config.php</code>.
                    <br><small><?= h($dbError) ?></small>
                </p>
            <?php else: ?>
                <p class="db-ok">
                    <i class="fa-solid fa-database"></i>
                    Conectado
                </p>
            <?php endif; ?>

            <div class="hero-actions">
                <a href="registro-visita.php" class="btn-principal">
                    <i class="fa-solid fa-user-plus"></i>
                    Registrar Visita
                    <i class="fa-solid fa-arrow-right"></i>
                </a>
                <a href="catalogo-libros.php" class="btn-secundario">
                    <i class="fa-solid fa-books"></i>
                    Catálogo de Libros
                </a>
                <a href="importar-usuarios.php" class="btn-secundario">
                    <i class="fa-solid fa-file-import"></i>
                    Importar usuarios
                </a>
            </div>

            <div class="stats stats-4">
                <div class="stat-card">
                    <i class="fa-solid fa-book" style="color:#4198C6"></i>
                    <div class="val"><?= number_format($stats['titulos']) ?></div>
                    <div class="lbl">Títulos en catálogo</div>
                </div>
                <div class="stat-card">
                    <i class="fa-solid fa-copy" style="color:#4198C6"></i>
                    <div class="val"><?= number_format($stats['copias']) ?></div>
                    <div class="lbl">Copias totales</div>
                </div>
                <div class="stat-card">
                    <i class="fa-solid fa-users" style="color:#4198C6"></i>
                    <div class="val"><?= number_format($stats['usuarios']) ?></div>
                    <div class="lbl">Usuarios registrados</div>
                </div>
                <div class="stat-card">
                    <i class="fa-solid fa-clock" style="color:#4198C6"></i>
                    <div class="val"><?= number_format($stats['visitas_mes']) ?></div>
                    <div class="lbl">Visitas este mes</div>
                </div>
            </div>
        </div>
    </main>

    <footer class="footer-inicio">
        © <?= date('Y') ?> Universidad Politécnica de Juventino Rosas · Dirección de Servicios Bibliotecarios
    </footer>
</body>
</html>
