-- Creacion de BD biblipteca 
CREATE DATABASE IF NOT EXISTS biblioteca_upjr
  CHARACTER SET utf8mb4 -- ESTO ES PARA LOS ACENTOS :v
  COLLATE utf8mb4_unicode_ci;  -- ESTO NOS AYUDA  PARA COMparar las letras MIN/MAYUS y acentos diferencia entre lellas
  

USE biblioteca_upjr;
-- TABLA CHINGONA -- 
create table libros_prueba
(
id_libro int primary key auto_increment, 
isbn varchar(150),
titulo varchar(250),
autor varchar(250),
editorial varchar(150), 
edicion varchar(50),
anio_publicacion varchar(10),
copias int, 
Estante varchar(10),
Repisa varchar(10),
Clase varchar(150)
);

-- FIN TABLA CHINGONA -- 

select * from libros_prueba;



-- Crear la tabla programa educativo
CREATE TABLE programa_educativo (
  id_programa INT AUTO_INCREMENT PRIMARY KEY,
  nombre VARCHAR(100) NOT NULL UNIQUE
) ENGINE=InnoDB;

-- meter datos a la tabla programa educativo
INSERT INTO programa_educativo (nombre)
values("LICENCIATURA EN ADMINISTRACIÓN")



SELECT * FROM programa_educativo; 

-- Crear tabla usuario
CREATE TABLE usuario (
  matricula VARCHAR(20) PRIMARY KEY,
  nombre VARCHAR(100) NOT NULL,
  correo VARCHAR(100),
  grado VARCHAR(20),
  sexo CHAR(1),
  estatus VARCHAR(20),
  tutor VARCHAR(100),
  id_programa INT,
  FOREIGN KEY (id_programa) REFERENCES programa_educativo(id_programa)
    ON DELETE SET NULL ON UPDATE CASCADE,
  INDEX idx_usuario_programa (id_programa)
) ENGINE=InnoDB;


-- 2. Insertar agrupando SOLO por ISBN (maneja duplicados)
INSERT IGNORE INTO libro (isbn, titulo, autor, editorial, edicion, anio_publicacion, estante, repisa, total_copias)
SELECT 
  CASE WHEN TRIM(isbn) IN ('No aplica', 'No Aplica', '') THEN NULL ELSE TRIM(isbn) END AS isbn,
  ANY_VALUE(titulo) AS titulo,
  ANY_VALUE(NULLIF(TRIM(autor), '')) AS autor,
  ANY_VALUE(NULLIF(TRIM(editorial), '')) AS editorial,
  ANY_VALUE(NULLIF(TRIM(edicion), '')) AS edicion,
  ANY_VALUE(NULLIF(TRIM(anio_publicacion), '')) AS anio_publicacion,
  ANY_VALUE(NULLIF(TRIM(Estante), '')) AS estante,
  ANY_VALUE(NULLIF(TRIM(Repisa), '')) AS repisa,
  SUM(copias) AS total_copias
FROM libros_prueba
WHERE titulo IS NOT NULL AND TRIM(titulo) != ''
GROUP BY isbn;  -- 👈 solo por ISBN

SELECT * FROM libro WHERE total_copias IS NULL;



--  Crear tabla actividad
CREATE TABLE actividad (
  id_actividad INT AUTO_INCREMENT PRIMARY KEY,
  descripcion VARCHAR(80) NOT NULL UNIQUE
) ENGINE=InnoDB;

INSERT INTO actividad (descripcion) VALUES 
  ('TAREAS/INVESTIGACIONES'),
  ('CONSULTA DE LIBRO'),
  ('JUEGOS DE MESA'),
  ('CLASE'),
  ('NINGUNA');
  
  -- Ccrear tabla vista_registro
  CREATE TABLE visita_registro (
  id_visita INT AUTO_INCREMENT PRIMARY KEY,
  matricula VARCHAR(20) NOT NULL,
  id_actividad INT NOT NULL,
  fecha_hora DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (matricula) REFERENCES usuario(matricula)
    ON DELETE CASCADE ON UPDATE CASCADE,
  FOREIGN KEY (id_actividad) REFERENCES actividad(id_actividad)
    ON DELETE RESTRICT ON UPDATE CASCADE,
  INDEX idx_visita_usuario (matricula),
  INDEX idx_visita_actividad (id_actividad),
  INDEX idx_visita_fecha (fecha_hora)
) ENGINE=InnoDB;

-- Crear tabla prestamos
CREATE TABLE prestamo (
  id_prestamo INT AUTO_INCREMENT PRIMARY KEY,
  id_visita INT,
  id_libro INT NOT NULL,
  fecha_salida DATETIME DEFAULT CURRENT_TIMESTAMP,
  fecha_devolucion_programada DATE NOT NULL,
  fecha_devolucion_real DATETIME,
  estado VARCHAR(20) DEFAULT 'ACTIVO',
  FOREIGN KEY (id_visita) REFERENCES visita_registro(id_visita)
    ON DELETE SET NULL ON UPDATE CASCADE,
  FOREIGN KEY (id_libro) REFERENCES libro(id_libro)
    ON DELETE RESTRICT ON UPDATE CASCADE,
  INDEX idx_prestamo_visita (id_visita),
  INDEX idx_prestamo_libro (id_libro),
  INDEX idx_prestamo_estado (estado)
) ENGINE=InnoDB;


-- vista para ver los libros disponibles
CREATE VIEW vista_disponibilidad_libros AS
SELECT 
  l.id_libro,
  l.isbn,
  l.titulo,
  l.autor,
  l.editorial,
  l.total_copias AS copias_totales,
  COALESCE(l.total_copias - COUNT(p.id_prestamo), l.total_copias) AS copias_disponibles
FROM libro l
LEFT JOIN prestamo p ON p.id_libro = l.id_libro AND p.estado = 'ACTIVO'
GROUP BY l.id_libro;

-- consulta para la vista
SELECT * FROM vista_disponibilidad_libros WHERE copias_disponibles > 0;





