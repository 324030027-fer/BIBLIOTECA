
  # Interfaz Registro de Visitas

  This is a code bundle for Interfaz Registro de Visitas. The original project is available at https://www.figma.com/design/tUlRSHeZkZ3OyLCKG58gGC/Interfaz-Registro-de-Visitas.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  