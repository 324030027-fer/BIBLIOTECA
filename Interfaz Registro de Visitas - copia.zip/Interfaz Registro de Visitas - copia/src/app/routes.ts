import { createBrowserRouter } from "react-router";
import { Root } from "./components/Root";
import { WelcomeScreen } from "./components/WelcomeScreen";
import { RegistroVisita } from "./components/RegistroVisita";

export const router = createBrowserRouter([
  {
    path: "/",
    Component: Root,
    children: [
      { index: true, Component: WelcomeScreen },
      { path: "registro-visita", Component: RegistroVisita },
    ],
  },
]);
