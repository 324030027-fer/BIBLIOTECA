import { useState, useRef, useEffect } from "react";
import { useNavigate } from "react-router";
import {
  Search, User, ChevronLeft, BookOpen, Laptop, Printer,
  Coffee, Users, FileText, CheckCircle, X, Calendar, Clock,
  GraduationCap, IdCard, Phone, Mail,
} from "lucide-react";

interface Usuario {
  id: string;
  nombre: string;
  apellidos: string;
  matricula: string;
  carrera: string;
  semestre: number;
  telefono: string;
  email: string;
  tipo: "Estudiante" | "Docente" | "Externo";
}

const USUARIOS_MOCK: Usuario[] = [
  { id: "1", nombre: "María", apellidos: "González Pérez", matricula: "2021-0001", carrera: "Ingeniería en Tecnologías de la Información", semestre: 6, telefono: "461-123-4567", email: "maria.gonzalez@upjr.edu.mx", tipo: "Estudiante" },
  { id: "2", nombre: "Carlos", apellidos: "Ramírez López", matricula: "2020-0142", carrera: "Ingeniería Industrial", semestre: 8, telefono: "461-234-5678", email: "carlos.ramirez@upjr.edu.mx", tipo: "Estudiante" },
  { id: "3", nombre: "Ana Luisa", apellidos: "Hernández Torres", matricula: "2022-0356", carrera: "Ingeniería en Mecatrónica", semestre: 4, telefono: "461-345-6789", email: "ana.hernandez@upjr.edu.mx", tipo: "Estudiante" },
  { id: "4", nombre: "Dr. José", apellidos: "Martínez Olvera", matricula: "DOC-0023", carrera: "Ingeniería en Tecnologías de la Información", semestre: 0, telefono: "461-456-7890", email: "jose.martinez@upjr.edu.mx", tipo: "Docente" },
  { id: "5", nombre: "Luis Miguel", apellidos: "Vega Sandoval", matricula: "2023-0089", carrera: "Ingeniería Financiera", semestre: 3, telefono: "461-567-8901", email: "luis.vega@upjr.edu.mx", tipo: "Estudiante" },
  { id: "6", nombre: "Sofía", apellidos: "Morales Gutiérrez", matricula: "2021-0278", carrera: "Ingeniería en Nanotecnología", semestre: 7, telefono: "461-678-9012", email: "sofia.morales@upjr.edu.mx", tipo: "Estudiante" },
  { id: "7", nombre: "Ing. Patricia", apellidos: "Flores Ruiz", matricula: "DOC-0041", carrera: "Ingeniería Industrial", semestre: 0, telefono: "461-789-0123", email: "patricia.flores@upjr.edu.mx", tipo: "Docente" },
  { id: "8", nombre: "Roberto", apellidos: "Cruz Jiménez", matricula: "EXT-001", carrera: "N/A", semestre: 0, telefono: "461-890-1234", email: "roberto.cruz@gmail.com", tipo: "Externo" },
];

const ACTIVIDADES = [
  { id: "consulta", label: "Consulta de material", icon: BookOpen },
  { id: "computo", label: "Uso de equipo de cómputo", icon: Laptop },
  { id: "impresion", label: "Impresión / Escaneo", icon: Printer },
  { id: "sala", label: "Sala de estudio grupal", icon: Users },
  { id: "tesis", label: "Asesoría de tesis / Investigación", icon: FileText },
  { id: "descanso", label: "Área de descanso / Lectura", icon: Coffee },
];

function getTipoColor(tipo: string) {
  if (tipo === "Docente") return { bg: "#4198C6", text: "white" };
  if (tipo === "Externo") return { bg: "#F97316", text: "white" };
  return { bg: "#16a34a", text: "white" };
}

function getCurrentTime() {
  return new Date().toLocaleTimeString("es-MX", { hour: "2-digit", minute: "2-digit" });
}

function getCurrentDate() {
  return new Date().toLocaleDateString("es-MX", { weekday: "long", year: "numeric", month: "long", day: "numeric" });
}

export function RegistroVisita() {
  const navigate = useNavigate();
  const [query, setQuery] = useState("");
  const [resultados, setResultados] = useState<Usuario[]>([]);
  const [usuarioSeleccionado, setUsuarioSeleccionado] = useState<Usuario | null>(null);
  const [showDropdown, setShowDropdown] = useState(false);
  const [actividades, setActividades] = useState<string[]>([]);
  const [observaciones, setObservaciones] = useState("");
  const [registrado, setRegistrado] = useState(false);
  const [currentTime, setCurrentTime] = useState(getCurrentTime());
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    const interval = setInterval(() => setCurrentTime(getCurrentTime()), 1000);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    if (query.trim().length < 2) {
      setResultados([]);
      setShowDropdown(false);
      return;
    }
    const q = query.toLowerCase();
    const filtrados = USUARIOS_MOCK.filter(
      (u) =>
        u.nombre.toLowerCase().includes(q) ||
        u.apellidos.toLowerCase().includes(q) ||
        u.matricula.toLowerCase().includes(q) ||
        u.carrera.toLowerCase().includes(q)
    );
    setResultados(filtrados);
    setShowDropdown(true);
  }, [query]);

  const seleccionarUsuario = (u: Usuario) => {
    setUsuarioSeleccionado(u);
    setQuery(`${u.nombre} ${u.apellidos}`);
    setShowDropdown(false);
    setActividades([]);
    setObservaciones("");
    setRegistrado(false);
  };

  const limpiarSeleccion = () => {
    setUsuarioSeleccionado(null);
    setQuery("");
    setActividades([]);
    setObservaciones("");
    setRegistrado(false);
    inputRef.current?.focus();
  };

  const toggleActividad = (id: string) => {
    setActividades((prev) =>
      prev.includes(id) ? prev.filter((a) => a !== id) : [...prev, id]
    );
  };

  const handleRegistrar = () => {
    if (!usuarioSeleccionado || actividades.length === 0) return;
    setRegistrado(true);
  };

  const handleNuevoRegistro = () => {
    setUsuarioSeleccionado(null);
    setQuery("");
    setActividades([]);
    setObservaciones("");
    setRegistrado(false);
    setTimeout(() => inputRef.current?.focus(), 100);
  };

  return (
    <div className="min-h-screen flex flex-col" style={{ background: "linear-gradient(135deg, #f0f7ff 0%, #e8f4fd 100%)" }}>
      {/* Header */}
      <header style={{ background: "linear-gradient(90deg, #0a1f2e 0%, #1a4a6b 100%)", borderBottom: "3px solid #F97316" }}>
        <div className="max-w-6xl mx-auto px-6 py-4 flex items-center justify-between">
          <button
            onClick={() => navigate("/")}
            className="flex items-center gap-2 px-4 py-2 rounded-xl text-white/80 hover:text-white hover:bg-white/10 transition-all duration-200"
          >
            <ChevronLeft className="w-5 h-5" />
            <span className="text-sm">Inicio</span>
          </button>

          <div className="flex flex-col items-center">
            <h2 className="text-white" style={{ fontSize: "1.1rem", fontWeight: 700 }}>
              Registro de Visita
            </h2>
            <p className="text-white/50 text-xs">Biblioteca · UPJR</p>
          </div>

          <div className="flex items-center gap-3 text-right">
            <div>
              <div className="flex items-center gap-1.5 justify-end">
                <Clock className="w-3.5 h-3.5" style={{ color: "#4198C6" }} />
                <span className="text-white text-sm font-mono font-semibold">{currentTime}</span>
              </div>
              <div className="flex items-center gap-1.5 justify-end mt-0.5">
                <Calendar className="w-3 h-3 text-white/40" />
                <span className="text-white/50 text-xs capitalize">{getCurrentDate()}</span>
              </div>
            </div>
          </div>
        </div>
      </header>

      <main className="flex-1 max-w-6xl mx-auto w-full px-6 py-8">
        {/* Buscador */}
        <div className="mb-8">
          <div className="text-center mb-6">
            <h1 className="text-3xl font-extrabold mb-2" style={{ color: "#0a1f2e" }}>
              Busca al <span style={{ color: "#F97316" }}>Visitante</span>
            </h1>
            <p className="text-gray-500 text-sm">Ingresa el nombre, apellidos o matrícula del usuario</p>
          </div>

          <div className="relative max-w-2xl mx-auto">
            <div
              className="flex items-center gap-3 px-5 py-4 rounded-2xl shadow-lg border-2 transition-all duration-200"
              style={{
                background: "white",
                borderColor: showDropdown || usuarioSeleccionado ? "#4198C6" : "rgba(65,152,198,0.3)",
                boxShadow: "0 4px 20px rgba(65,152,198,0.15)",
              }}
            >
              <Search className="w-5 h-5 flex-shrink-0" style={{ color: "#4198C6" }} />
              <input
                ref={inputRef}
                type="text"
                value={query}
                onChange={(e) => {
                  setQuery(e.target.value);
                  if (usuarioSeleccionado) setUsuarioSeleccionado(null);
                }}
                onFocus={() => resultados.length > 0 && setShowDropdown(true)}
                placeholder="Buscar por nombre, apellido o matrícula..."
                className="flex-1 outline-none bg-transparent text-gray-800 placeholder-gray-400"
                style={{ fontSize: "1rem" }}
              />
              {query && (
                <button onClick={limpiarSeleccion} className="text-gray-400 hover:text-gray-600 transition-colors">
                  <X className="w-4 h-4" />
                </button>
              )}
            </div>

            {/* Dropdown resultados */}
            {showDropdown && (
              <div
                className="absolute top-full left-0 right-0 mt-2 rounded-2xl shadow-2xl border overflow-hidden z-50"
                style={{ background: "white", borderColor: "rgba(65,152,198,0.2)", maxHeight: "320px", overflowY: "auto" }}
              >
                {resultados.length === 0 ? (
                  <div className="px-5 py-6 text-center text-gray-400">
                    <User className="w-8 h-8 mx-auto mb-2 opacity-40" />
                    <p className="text-sm">No se encontraron usuarios</p>
                  </div>
                ) : (
                  resultados.map((u) => {
                    const tipoColor = getTipoColor(u.tipo);
                    return (
                      <button
                        key={u.id}
                        onClick={() => seleccionarUsuario(u)}
                        className="w-full flex items-center gap-4 px-5 py-4 hover:bg-blue-50 transition-colors duration-150 text-left border-b last:border-0"
                        style={{ borderColor: "rgba(0,0,0,0.05)" }}
                      >
                        <div
                          className="w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0"
                          style={{ background: "linear-gradient(135deg, #4198C6, #2c7aad)" }}
                        >
                          <span className="text-white text-sm font-bold">
                            {u.nombre[0]}{u.apellidos[0]}
                          </span>
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="font-semibold text-gray-800 truncate">{u.nombre} {u.apellidos}</p>
                          <p className="text-gray-400 text-xs truncate">{u.matricula} · {u.carrera !== "N/A" ? u.carrera : "Visitante externo"}</p>
                        </div>
                        <span
                          className="text-xs px-2.5 py-1 rounded-full flex-shrink-0"
                          style={{ background: tipoColor.bg, color: tipoColor.text, fontWeight: 600 }}
                        >
                          {u.tipo}
                        </span>
                      </button>
                    );
                  })
                )}
              </div>
            )}
          </div>
        </div>

        {/* Formulario de registro */}
        {usuarioSeleccionado && !registrado && (
          <div className="max-w-4xl mx-auto animate-in fade-in slide-in-from-bottom-4 duration-400">
            {/* Tarjeta del usuario */}
            <div
              className="rounded-3xl p-6 mb-6 shadow-xl"
              style={{
                background: "linear-gradient(135deg, #0a1f2e 0%, #1a4a6b 100%)",
                border: "2px solid rgba(65,152,198,0.4)",
              }}
            >
              <div className="flex items-start gap-5">
                <div
                  className="w-16 h-16 rounded-2xl flex items-center justify-center flex-shrink-0 shadow-lg"
                  style={{ background: "linear-gradient(135deg, #F97316, #e8620a)" }}
                >
                  <span className="text-white text-xl font-bold">
                    {usuarioSeleccionado.nombre[0]}{usuarioSeleccionado.apellidos[0]}
                  </span>
                </div>
                <div className="flex-1">
                  <div className="flex items-center gap-3 mb-1">
                    <h3 className="text-white font-bold" style={{ fontSize: "1.2rem" }}>
                      {usuarioSeleccionado.nombre} {usuarioSeleccionado.apellidos}
                    </h3>
                    <span
                      className="text-xs px-2.5 py-1 rounded-full font-semibold"
                      style={{ background: getTipoColor(usuarioSeleccionado.tipo).bg, color: "white" }}
                    >
                      {usuarioSeleccionado.tipo}
                    </span>
                  </div>
                  <div className="grid grid-cols-2 gap-x-6 gap-y-1.5 mt-3">
                    <div className="flex items-center gap-2">
                      <IdCard className="w-3.5 h-3.5" style={{ color: "#4198C6" }} />
                      <span className="text-white/70 text-xs">{usuarioSeleccionado.matricula}</span>
                    </div>
                    {usuarioSeleccionado.semestre > 0 && (
                      <div className="flex items-center gap-2">
                        <GraduationCap className="w-3.5 h-3.5" style={{ color: "#4198C6" }} />
                        <span className="text-white/70 text-xs">Semestre {usuarioSeleccionado.semestre}</span>
                      </div>
                    )}
                    <div className="flex items-center gap-2">
                      <Phone className="w-3.5 h-3.5" style={{ color: "#4198C6" }} />
                      <span className="text-white/70 text-xs">{usuarioSeleccionado.telefono}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Mail className="w-3.5 h-3.5" style={{ color: "#4198C6" }} />
                      <span className="text-white/70 text-xs truncate">{usuarioSeleccionado.email}</span>
                    </div>
                    {usuarioSeleccionado.carrera !== "N/A" && (
                      <div className="flex items-center gap-2 col-span-2">
                        <BookOpen className="w-3.5 h-3.5 flex-shrink-0" style={{ color: "#4198C6" }} />
                        <span className="text-white/70 text-xs">{usuarioSeleccionado.carrera}</span>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </div>

            {/* Formulario de actividad */}
            <div
              className="rounded-3xl p-7 shadow-xl"
              style={{ background: "white", border: "2px solid rgba(65,152,198,0.15)" }}
            >
              <div className="mb-6">
                <h3 className="font-bold text-gray-800 mb-1" style={{ fontSize: "1.05rem" }}>
                  Actividad a realizar
                </h3>
                <p className="text-gray-400 text-xs">Selecciona una o más actividades (requerido)</p>
              </div>

              <div className="grid grid-cols-2 gap-3 mb-7">
                {ACTIVIDADES.map(({ id, label, icon: Icon }) => {
                  const selected = actividades.includes(id);
                  return (
                    <button
                      key={id}
                      onClick={() => toggleActividad(id)}
                      className="flex items-center gap-3 px-4 py-4 rounded-2xl border-2 transition-all duration-200 text-left"
                      style={{
                        background: selected ? "linear-gradient(135deg, #4198C6, #2c7aad)" : "white",
                        borderColor: selected ? "#4198C6" : "rgba(0,0,0,0.08)",
                        boxShadow: selected ? "0 4px 14px rgba(65,152,198,0.3)" : "none",
                        transform: selected ? "scale(1.02)" : "scale(1)",
                      }}
                    >
                      <div
                        className="w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0"
                        style={{ background: selected ? "rgba(255,255,255,0.2)" : "rgba(65,152,198,0.1)" }}
                      >
                        <Icon className="w-4.5 h-4.5" style={{ color: selected ? "white" : "#4198C6" }} />
                      </div>
                      <span
                        className="text-sm font-medium"
                        style={{ color: selected ? "white" : "#374151" }}
                      >
                        {label}
                      </span>
                    </button>
                  );
                })}
              </div>

              {/* Observaciones */}
              <div className="mb-7">
                <label className="text-gray-700 text-sm font-semibold block mb-2">
                  Observaciones <span className="text-gray-400 font-normal">(opcional)</span>
                </label>
                <textarea
                  value={observaciones}
                  onChange={(e) => setObservaciones(e.target.value)}
                  placeholder="Agrega notas adicionales sobre la visita..."
                  rows={3}
                  className="w-full px-4 py-3 rounded-xl border-2 outline-none resize-none text-gray-700 placeholder-gray-300 transition-all duration-200 focus:border-blue-400"
                  style={{ borderColor: "rgba(0,0,0,0.1)", fontSize: "0.9rem" }}
                />
              </div>

              {/* Info de hora */}
              <div
                className="flex items-center gap-3 px-4 py-3 rounded-xl mb-7"
                style={{ background: "rgba(65,152,198,0.08)", border: "1px solid rgba(65,152,198,0.2)" }}
              >
                <Clock className="w-4 h-4 flex-shrink-0" style={{ color: "#4198C6" }} />
                <p className="text-xs" style={{ color: "#2c7aad" }}>
                  La visita se registrará con hora de entrada: <strong>{currentTime}</strong> · {getCurrentDate()}
                </p>
              </div>

              {/* Botón registrar */}
              <button
                onClick={handleRegistrar}
                disabled={actividades.length === 0}
                className="w-full py-4 rounded-2xl text-white font-bold transition-all duration-300"
                style={{
                  background: actividades.length > 0
                    ? "linear-gradient(135deg, #F97316, #e8620a)"
                    : "rgba(0,0,0,0.1)",
                  color: actividades.length > 0 ? "white" : "#9ca3af",
                  boxShadow: actividades.length > 0 ? "0 6px 20px rgba(249,115,22,0.35)" : "none",
                  fontSize: "1rem",
                  cursor: actividades.length > 0 ? "pointer" : "not-allowed",
                }}
              >
                {actividades.length === 0 ? "Selecciona al menos una actividad" : "Confirmar Registro de Visita"}
              </button>
            </div>
          </div>
        )}

        {/* Pantalla de éxito */}
        {registrado && usuarioSeleccionado && (
          <div className="max-w-lg mx-auto text-center animate-in fade-in zoom-in-95 duration-500">
            <div
              className="rounded-3xl p-10 shadow-2xl"
              style={{
                background: "linear-gradient(135deg, #0a1f2e 0%, #1a4a6b 100%)",
                border: "2px solid rgba(65,152,198,0.4)",
              }}
            >
              <div
                className="w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-5 shadow-xl"
                style={{ background: "linear-gradient(135deg, #16a34a, #15803d)" }}
              >
                <CheckCircle className="w-10 h-10 text-white" />
              </div>
              <h2 className="text-white mb-2" style={{ fontSize: "1.5rem", fontWeight: 800 }}>
                ¡Visita Registrada!
              </h2>
              <p className="text-white/60 text-sm mb-6">
                El acceso de <strong className="text-white">{usuarioSeleccionado.nombre} {usuarioSeleccionado.apellidos}</strong> ha sido registrado exitosamente.
              </p>

              <div className="text-left rounded-2xl p-4 mb-6" style={{ background: "rgba(255,255,255,0.07)" }}>
                <p className="text-white/50 text-xs mb-2 font-semibold uppercase tracking-wider">Actividades registradas</p>
                {actividades.map((id) => {
                  const act = ACTIVIDADES.find((a) => a.id === id);
                  if (!act) return null;
                  const Icon = act.icon;
                  return (
                    <div key={id} className="flex items-center gap-2 py-1.5">
                      <Icon className="w-3.5 h-3.5" style={{ color: "#4198C6" }} />
                      <span className="text-white/80 text-sm">{act.label}</span>
                    </div>
                  );
                })}
                <div className="flex items-center gap-2 pt-2 mt-2" style={{ borderTop: "1px solid rgba(255,255,255,0.1)" }}>
                  <Clock className="w-3.5 h-3.5" style={{ color: "#F97316" }} />
                  <span className="text-white/60 text-xs">Hora de entrada: {currentTime}</span>
                </div>
              </div>

              <div className="flex gap-3">
                <button
                  onClick={handleNuevoRegistro}
                  className="flex-1 py-3.5 rounded-xl font-semibold transition-all duration-200 hover:scale-105"
                  style={{
                    background: "linear-gradient(135deg, #F97316, #e8620a)",
                    color: "white",
                    boxShadow: "0 4px 14px rgba(249,115,22,0.35)",
                  }}
                >
                  Nueva Visita
                </button>
                <button
                  onClick={() => navigate("/")}
                  className="flex-1 py-3.5 rounded-xl font-semibold border transition-all duration-200 hover:bg-white/10"
                  style={{ borderColor: "rgba(65,152,198,0.4)", color: "rgba(255,255,255,0.7)" }}
                >
                  Ir al Inicio
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Estado vacío */}
        {!usuarioSeleccionado && !registrado && query.length < 2 && (
          <div className="text-center mt-8 text-gray-400">
            <Search className="w-12 h-12 mx-auto mb-3 opacity-30" />
            <p className="text-sm">Escribe al menos 2 caracteres para buscar un usuario</p>
          </div>
        )}
      </main>
    </div>
  );
}
