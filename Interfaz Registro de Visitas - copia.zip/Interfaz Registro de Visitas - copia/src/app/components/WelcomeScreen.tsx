import { useNavigate } from "react-router";
import { BookOpen, Users, Clock, ArrowRight, Library } from "lucide-react";
import { ImageWithFallback } from "./figma/ImageWithFallback";

const LIBRARY_IMAGE =
  "https://images.unsplash.com/photo-1749660354104-9a5ab1225805?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx1bml2ZXJzaXR5JTIwbGlicmFyeSUyMGJvb2tzJTIwYWNhZGVtaWN8ZW58MXx8fHwxNzc5MjA4OTQ2fDA&ixlib=rb-4.1.0&q=80&w=1080";

const stats = [
  { icon: BookOpen, label: "Acervos Disponibles", value: "12,450+" },
  { icon: Users, label: "Usuarios Registrados", value: "3,200+" },
  { icon: Clock, label: "Visitas Este Mes", value: "1,870" },
];

function UpjrLogo() {
  return (
    <div className="flex items-center justify-center w-16 h-16 rounded-full bg-white shadow-md overflow-hidden border-2 border-orange-400">
      <svg viewBox="0 0 64 64" className="w-12 h-12" fill="none">
        <circle cx="32" cy="32" r="28" fill="#4198C6" />
        <text x="32" y="28" textAnchor="middle" fill="white" fontSize="9" fontWeight="bold" fontFamily="Arial">UPJR</text>
        <text x="32" y="40" textAnchor="middle" fill="#FFA500" fontSize="5" fontFamily="Arial">POLITÉCNICA</text>
        <text x="32" y="49" textAnchor="middle" fill="white" fontSize="4.5" fontFamily="Arial">JUVENTINO ROSAS</text>
      </svg>
    </div>
  );
}

function SepLogo() {
  return (
    <div className="flex items-center justify-center w-14 h-14 rounded-full bg-white shadow-md overflow-hidden border-2 border-blue-300">
      <svg viewBox="0 0 64 64" className="w-10 h-10" fill="none">
        <circle cx="32" cy="32" r="28" fill="#1a5276" />
        <text x="32" y="30" textAnchor="middle" fill="white" fontSize="11" fontWeight="bold" fontFamily="Arial">SEP</text>
        <text x="32" y="42" textAnchor="middle" fill="#f0f0f0" fontSize="4.5" fontFamily="Arial">SECRETARÍA DE</text>
        <text x="32" y="50" textAnchor="middle" fill="#f0f0f0" fontSize="4.5" fontFamily="Arial">EDUCACIÓN</text>
      </svg>
    </div>
  );
}

function TecnmLogo() {
  return (
    <div className="flex items-center justify-center w-14 h-14 rounded-full bg-white shadow-md overflow-hidden border-2 border-orange-300">
      <svg viewBox="0 0 64 64" className="w-10 h-10" fill="none">
        <circle cx="32" cy="32" r="28" fill="#c0392b" />
        <text x="32" y="28" textAnchor="middle" fill="white" fontSize="8" fontWeight="bold" fontFamily="Arial">TECNM</text>
        <text x="32" y="40" textAnchor="middle" fill="#FFD700" fontSize="4.5" fontFamily="Arial">TECNOLÓGICO</text>
        <text x="32" y="49" textAnchor="middle" fill="white" fontSize="4.5" fontFamily="Arial">NACIONAL</text>
      </svg>
    </div>
  );
}

export function WelcomeScreen() {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen flex flex-col" style={{ background: "linear-gradient(135deg, #0d2b3e 0%, #1a4a6b 40%, #1f5a80 100%)" }}>
      {/* Header institucional con logos */}
      <header className="w-full" style={{ background: "linear-gradient(90deg, #0a1f2e 0%, #122b40 100%)", borderBottom: "3px solid #F97316" }}>
        <div className="max-w-7xl mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            {/* Logos institucionales */}
            <div className="flex items-center gap-5">
              <SepLogo />
              <div className="h-10 w-px bg-white/20" />
              <TecnmLogo />
            </div>

            {/* Logo central UPJR */}
            <div className="flex flex-col items-center gap-1">
              <UpjrLogo />
              <div className="text-center">
                <p className="text-white/90 text-xs tracking-widest uppercase">Universidad Politécnica de Juventino Rosas</p>
              </div>
            </div>

            {/* Fecha y hora */}
            <div className="text-right">
              <p className="text-orange-400 text-sm font-semibold">Biblioteca Universitaria</p>
              <p className="text-white/60 text-xs mt-0.5">Sistema de Registro de Visitas</p>
            </div>
          </div>
        </div>
      </header>

      {/* Hero principal */}
      <main className="flex-1 flex flex-col items-center justify-center relative overflow-hidden">
        {/* Imagen de fondo con overlay */}
        <div className="absolute inset-0 z-0">
          <ImageWithFallback
            src={LIBRARY_IMAGE}
            alt="Biblioteca universitaria"
            className="w-full h-full object-cover opacity-15"
          />
          <div className="absolute inset-0" style={{ background: "linear-gradient(135deg, rgba(13,43,62,0.92) 0%, rgba(26,74,107,0.85) 100%)" }} />
        </div>

        {/* Decorative circles */}
        <div className="absolute top-10 right-20 w-64 h-64 rounded-full opacity-10 z-0" style={{ background: "#F97316", filter: "blur(60px)" }} />
        <div className="absolute bottom-20 left-10 w-80 h-80 rounded-full opacity-10 z-0" style={{ background: "#4198C6", filter: "blur(80px)" }} />

        <div className="relative z-10 flex flex-col items-center text-center px-6 max-w-4xl mx-auto">
          {/* Ícono decorativo */}
          <div className="mb-6 flex items-center justify-center w-24 h-24 rounded-full shadow-2xl" style={{ background: "linear-gradient(135deg, #F97316, #e8620a)" }}>
            <Library className="w-12 h-12 text-white" />
          </div>

          {/* Título */}
          <h1 className="text-white mb-2" style={{ fontSize: "2.8rem", fontWeight: 800, lineHeight: 1.15 }}>
            Sistema de Registro
          </h1>
          <h1 className="mb-4" style={{ fontSize: "2.8rem", fontWeight: 800, lineHeight: 1.15, color: "#F97316" }}>
            de Visitas
          </h1>
          <div className="h-1 w-24 rounded-full mb-6" style={{ background: "linear-gradient(90deg, #F97316, #4198C6)" }} />
          <p className="text-white/70 text-lg mb-2 max-w-xl">
            Biblioteca Central · Universidad Politécnica de Juventino Rosas
          </p>
          <p className="text-white/50 text-sm mb-12 max-w-lg">
            Registra tu visita de manera rápida y sencilla. Lleva un control eficiente de los servicios que utilizas en la biblioteca.
          </p>

          {/* Botón principal */}
          <button
            onClick={() => navigate("/registro-visita")}
            className="group flex items-center gap-3 px-10 py-5 rounded-2xl text-white shadow-2xl transition-all duration-300 hover:scale-105 hover:shadow-orange-500/30"
            style={{
              background: "linear-gradient(135deg, #F97316, #e8620a)",
              boxShadow: "0 8px 32px rgba(249,115,22,0.4)",
              fontSize: "1.15rem",
              fontWeight: 700,
            }}
          >
            <BookOpen className="w-6 h-6" />
            Registrar Visita
            <ArrowRight className="w-5 h-5 transition-transform duration-300 group-hover:translate-x-1" />
          </button>

          {/* Estadísticas */}
          <div className="mt-16 grid grid-cols-3 gap-6 w-full max-w-2xl">
            {stats.map(({ icon: Icon, label, value }) => (
              <div
                key={label}
                className="flex flex-col items-center p-5 rounded-2xl border"
                style={{ background: "rgba(255,255,255,0.07)", borderColor: "rgba(65,152,198,0.3)", backdropFilter: "blur(10px)" }}
              >
                <Icon className="w-6 h-6 mb-2" style={{ color: "#4198C6" }} />
                <span className="text-white text-xl font-bold">{value}</span>
                <span className="text-white/50 text-xs mt-0.5 text-center">{label}</span>
              </div>
            ))}
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="py-4 text-center" style={{ background: "rgba(0,0,0,0.3)", borderTop: "1px solid rgba(65,152,198,0.2)" }}>
        <p className="text-white/40 text-xs">
          © 2026 Universidad Politécnica de Juventino Rosas · Dirección de Servicios Bibliotecarios
        </p>
      </footer>
    </div>
  );
}
