<?php

declare(strict_types=1);

require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/includes/funciones.php';

$q = trim((string) ($_GET['q'] ?? ''));
$pagina = max(1, (int) ($_GET['pagina'] ?? 1));
$porPagina = 25;
$offset = ($pagina - 1) * $porPagina;
$usuarios = [];
$total = 0;
$error = null;

try {
    $pdo = db();
    $params = [];
    $where = '';

    if ($q !== '') {
        $where = 'WHERE u.nombre LIKE :q OR u.matricula LIKE :q OR u.correo LIKE :q OR p.nombre LIKE :q';
        $params[':q'] = '%' . $q . '%';
    }

    $stmtCount = $pdo->prepare("SELECT COUNT(*) FROM usuario u LEFT JOIN programa_educativo p ON p.id_programa = u.id_programa $where");
    $stmtCount->execute($params);
    $total = (int) $stmtCount->fetchColumn();

    $sql = "SELECT u.matricula, u.nombre, u.correo, u.grado, u.sexo, u.estatus, u.tutor, p.nombre AS programa
            FROM usuario u
            LEFT JOIN programa_educativo p ON p.id_programa = u.id_programa
            $where
            ORDER BY u.nombre
            LIMIT $porPagina OFFSET $offset";
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $usuarios = $stmt->fetchAll();
} catch (Throwable $e) {
    $error = $e->getMessage();
}

$totalPag = max(1, (int) ceil($total / $porPagina));
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Usuarios · Biblioteca UPJR</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="assets/css/estilos.css">
</head>
<body class="page-registro">
    <header class="header-registro">
        <div class="header-inner">
            <a href="index.php" class="btn-volver"><i class="fa-solid fa-chevron-left"></i> Inicio</a>
            <div class="header-center">
                <h2 style="color:#fff;font-size:1.1rem;font-weight:700;">Usuarios registrados</h2>
                <p style="color:rgba(255,255,255,.5);font-size:.75rem;"><?= number_format($total) ?> en total</p>
            </div>
            <a href="registro-visita.php" class="btn-volver"><i class="fa-solid fa-user-plus"></i> Registro de visitas</a>
        </div>
    </header>

    <main class="main-registro catalogo-main">
        <?php if ($error): ?>
            <p class="msg-error"><?= h($error) ?></p>
        <?php else: ?>
            <form class="busqueda-wrap" method="get" style="margin-bottom:1.5rem;">
                <div class="busqueda-box">
                    <i class="fa-solid fa-magnifying-glass" style="color:#4198C6;"></i>
                    <input type="text" name="q" value="<?= h($q) ?>" placeholder="Buscar nombre, matrícula, correo o programa...">
                    <button type="submit" class="btn-mini">Buscar</button>
                </div>
            </form>

            <div class="tabla-wrap">
                <table class="tabla-libros">
                    <thead>
                        <tr>
                            <th>Matrícula</th>
                            <th>Nombre</th>
                            <th>Programa</th>
                            <th>Grado</th>
                            <th>Estatus</th>
                            <th>Correo</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (!$usuarios): ?>
                            <tr><td colspan="6" class="cargando">No hay usuarios registrados.</td></tr>
                        <?php else: ?>
                            <?php foreach ($usuarios as $u): ?>
                                <tr>
                                    <td><strong><?= h($u['matricula']) ?></strong></td>
                                    <td><?= h($u['nombre']) ?></td>
                                    <td><?= h($u['programa'] ?? '—') ?></td>
                                    <td><?= h($u['grado'] ?? '—') ?></td>
                                    <td><?= h($u['estatus'] ?? '—') ?></td>
                                    <td><?= h($u['correo'] ?? '—') ?></td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

            <?php if ($totalPag > 1): ?>
                <div class="paginacion">
                    <span class="pag-info">Página <?= $pagina ?> de <?= $totalPag ?></span>
                    <?php if ($pagina > 1): ?>
                        <a href="?q=<?= urlencode($q) ?>&pagina=<?= $pagina - 1 ?>" class="btn-mini">Anterior</a>
                    <?php endif; ?>
                    <?php if ($pagina < $totalPag): ?>
                        <a href="?q=<?= urlencode($q) ?>&pagina=<?= $pagina + 1 ?>" class="btn-mini">Siguiente</a>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
        <?php endif; ?>
    </main>
</body>
</html>
