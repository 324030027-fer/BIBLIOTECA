-- ============================================================
-- PASO 2: Tablas que te faltan (usuario + visita_registro)
-- Ejecuta esto en MySQL DESPUÉS de lo que ya tienes:
--   biblioteca_upjr, libros_prueba, programa_educativo, actividad
-- ============================================================

USE biblioteca_upjr;

-- Tabla de usuarios (alumnos / visitantes)
CREATE TABLE IF NOT EXISTS usuario (
  matricula VARCHAR(20) PRIMARY KEY,
  nombre VARCHAR(150) NOT NULL,
  correo VARCHAR(100),
  grado VARCHAR(20),
  sexo CHAR(1),
  estatus VARCHAR(20),
  tutor VARCHAR(150),
  id_programa INT,
  FOREIGN KEY (id_programa) REFERENCES programa_educativo(id_programa)
    ON DELETE SET NULL ON UPDATE CASCADE,
  INDEX idx_usuario_programa (id_programa),
  INDEX idx_usuario_nombre (nombre)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Tabla de visitas (una fila por actividad registrada)
CREATE TABLE IF NOT EXISTS visita_registro (
  id_visita INT AUTO_INCREMENT PRIMARY KEY,
  matricula VARCHAR(20) NOT NULL,
  id_actividad INT NOT NULL,
  fecha_hora DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (matricula) REFERENCES usuario(matricula)
    ON DELETE CASCADE ON UPDATE CASCADE,
  FOREIGN KEY (id_actividad) REFERENCES actividad(id_actividad)
    ON DELETE RESTRICT ON UPDATE CASCADE,
  INDEX idx_visita_usuario (matricula),
  INDEX idx_visita_actividad (id_actividad),
  INDEX idx_visita_fecha (fecha_hora)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Comprobar que se crearon
SHOW TABLES;
SELECT COUNT(*) AS total_actividades FROM actividad;
SELECT COUNT(*) AS total_programas FROM programa_educativo;
SELECT * FROM visita_registro ORDER BY fecha_hora DESC LIMIT 5;