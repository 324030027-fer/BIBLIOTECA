-- Referencia: usa la base de datos que ya creaste (biblioteca_upjr).
-- Este archivo NO reemplaza tu script; solo documenta las tablas que usa el sitio PHP.

USE biblioteca_upjr;

-- Libros (catálogo): libros_prueba y/o libro
-- Usuarios para el buscador de visitas
-- actividad + visita_registro para registrar visitas

-- Si aún no tienes la tabla libro normalizada:
CREATE TABLE IF NOT EXISTS libro (
  id_libro INT AUTO_INCREMENT PRIMARY KEY,
  isbn VARCHAR(150),
  titulo VARCHAR(250) NOT NULL,
  autor VARCHAR(250),
  editorial VARCHAR(150),
  edicion VARCHAR(50),
  anio_publicacion VARCHAR(10),
  estante VARCHAR(10),
  repisa VARCHAR(10),
  total_copias INT DEFAULT 0,
  INDEX idx_libro_titulo (titulo),
  INDEX idx_libro_autor (autor),
  INDEX idx_libro_isbn (isbn)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Actividades (si no las insertaste aún)
INSERT IGNORE INTO actividad (descripcion) VALUES
  ('TAREAS/INVESTIGACIONES'),
  ('CONSULTA DE LIBRO'),
  ('JUEGOS DE MESA'),
  ('CLASE'),
  ('NINGUNA');
