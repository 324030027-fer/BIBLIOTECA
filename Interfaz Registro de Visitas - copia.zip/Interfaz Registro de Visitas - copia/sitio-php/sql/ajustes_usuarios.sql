-- Ajustes recomendados antes de importar el CSV de matrículas (2503)
USE biblioteca_upjr;

-- Nombres y tutores pueden ser largos en el CSV oficial
ALTER TABLE usuario
  MODIFY nombre VARCHAR(150) NOT NULL,
  MODIFY tutor VARCHAR(150) NULL;

-- Los códigos de programa del CSV (TSU IFI, IFI, LAG, etc.) se insertan
-- automáticamente al ejecutar importar-usuarios.php
