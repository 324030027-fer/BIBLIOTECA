-- Usuarios de prueba para probar el registro de visitas (opcional)
USE biblioteca_upjr;

INSERT IGNORE INTO programa_educativo (nombre)
VALUES ('LICENCIATURA EN ADMINISTRACIÓN');

SET @prog = (SELECT id_programa FROM programa_educativo WHERE nombre LIKE '%ADMINISTRACIÓN%' LIMIT 1);

INSERT IGNORE INTO usuario (matricula, nombre, correo, grado, sexo, estatus, tutor, id_programa) VALUES
('2024-0001', 'María González Pérez', 'maria.gonzalez@upjr.edu.mx', '6', 'F', 'Activo', 'Lic. Ana Torres', @prog),
('2023-0142', 'Carlos Ramírez López', 'carlos.ramirez@upjr.edu.mx', '8', 'M', 'Activo', 'Lic. Ana Torres', @prog),
('DOC-0023', 'Dr. José Martínez Olvera', 'jose.martinez@upjr.edu.mx', 'N/A', 'M', 'Docente', NULL, @prog),
('EXT-001', 'Roberto Cruz Jiménez', 'roberto.cruz@gmail.com', 'N/A', 'M', 'Externo', NULL, NULL);
