<?php

declare(strict_types=1);

require_once __DIR__ . '/texto.php';

function h(?string $v): string
{
    return htmlspecialchars((string) $v, ENT_QUOTES, 'UTF-8');
}

/** Tabla de libros: `libro` normalizada o `libros_prueba` */
function fuente_libros(PDO $pdo): string
{
    static $tabla = null;
    if ($tabla !== null) {
        return $tabla;
    }
    $existe = $pdo->query("SHOW TABLES LIKE 'libro'")->fetchColumn();
    $tabla = $existe ? 'libro' : 'libros_prueba';

    return $tabla;
}

function actividades_desde_bd(PDO $pdo): array
{
    $stmt = $pdo->query(
        'SELECT id_actividad, descripcion FROM actividad ORDER BY id_actividad'
    );
    $lista = [];
    foreach ($stmt->fetchAll() as $fila) {
        $lista[(int) $fila['id_actividad']] = $fila['descripcion'];
    }

    return $lista;
}

function icono_actividad(string $descripcion): string
{
    $d = texto_upper($descripcion);
    if (str_contains($d, 'LIBRO') || str_contains($d, 'CONSULTA')) {
        return 'fa-book';
    }
    if (str_contains($d, 'TAREA') || str_contains($d, 'INVESTIG')) {
        return 'fa-file-lines';
    }
    if (str_contains($d, 'JUEGO')) {
        return 'fa-chess-board';
    }
    if (str_contains($d, 'CLASE')) {
        return 'fa-chalkboard-user';
    }

    return 'fa-circle-dot';
}

function tipo_usuario(string $matricula, ?string $estatus): string
{
    $m = texto_upper($matricula);
    if (str_starts_with($m, 'DOC')) {
        return 'Docente';
    }
    if (str_starts_with($m, 'EXT')) {
        return 'Externo';
    }
    if ($estatus && texto_stripos($estatus, 'docente') !== false) {
        return 'Docente';
    }

    return 'Estudiante';
}

function color_tipo(string $tipo): array
{
    return match ($tipo) {
        'Docente' => ['bg' => '#4198C6', 'text' => '#fff'],
        'Externo' => ['bg' => '#F97316', 'text' => '#fff'],
        default => ['bg' => '#16a34a', 'text' => '#fff'],
    };
}

function iniciales_nombre(string $nombre): string
{
    $partes = preg_split('/\s+/u', trim($nombre)) ?: [];
    if (count($partes) === 0) {
        return '?';
    }
    if (count($partes) === 1) {
        return texto_upper(texto_substr($partes[0], 0, 1));
    }

    return texto_upper(
        texto_substr($partes[0], 0, 1) . texto_substr($partes[1], 0, 1)
    );
}

function fecha_larga_es(): string
{
    $dias = ['domingo', 'lunes', 'martes', 'miércoles', 'jueves', 'viernes', 'sábado'];
    $meses = ['', 'enero', 'febrero', 'marzo', 'abril', 'mayo', 'junio', 'julio', 'agosto', 'septiembre', 'octubre', 'noviembre', 'diciembre'];
    $t = time();

    return $dias[(int) date('w', $t)] . ', ' . date('j', $t) . ' de ' . $meses[(int) date('n', $t)] . ' de ' . date('Y', $t);
}

function hora_actual(): string
{
    return date('H:i');
}

function estadisticas_inicio(PDO $pdo): array
{
    $tablaLibros = fuente_libros($pdo);

    if ($tablaLibros === 'libro') {
        $acervos = (int) $pdo->query('SELECT COUNT(*) FROM libro')->fetchColumn();
        $copias = (int) $pdo->query(
            'SELECT COALESCE(SUM(total_copias), 0) FROM libro'
        )->fetchColumn();
    } else {
        $acervos = (int) $pdo->query('SELECT COUNT(*) FROM libros_prueba')->fetchColumn();
        $copias = (int) $pdo->query(
            'SELECT COALESCE(SUM(copias), 0) FROM libros_prueba'
        )->fetchColumn();
    }

    $usuarios = 0;
    $visitasMes = 0;

    if ($pdo->query("SHOW TABLES LIKE 'usuario'")->fetchColumn()) {
        $usuarios = (int) $pdo->query('SELECT COUNT(*) FROM usuario')->fetchColumn();
    }
    if ($pdo->query("SHOW TABLES LIKE 'visita_registro'")->fetchColumn()) {
        $visitasMes = (int) $pdo->query(
            "SELECT COUNT(*) FROM visita_registro
             WHERE YEAR(fecha_hora) = YEAR(CURDATE())
               AND MONTH(fecha_hora) = MONTH(CURDATE())"
        )->fetchColumn();
    }

    return [
        'titulos' => $acervos,
        'copias' => $copias,
        'usuarios' => $usuarios,
        'visitas_mes' => $visitasMes,
        'fuente_libros' => $tablaLibros,
    ];
}

function visitas_exito_desde_sesion(PDO $pdo, array $datos): ?array
{
    $matricula = trim((string) ($datos['matricula'] ?? ''));
    $ids = array_map('intval', $datos['actividades_ids'] ?? []);
    $ids = array_filter($ids, static fn (int $id) => $id > 0);

    if ($matricula === '' || !$ids) {
        return null;
    }

    $stmtU = $pdo->prepare(
        'SELECT u.matricula, u.nombre, u.correo, u.grado, u.estatus,
                p.nombre AS programa
         FROM usuario u
         LEFT JOIN programa_educativo p ON p.id_programa = u.id_programa
         WHERE u.matricula = :m'
    );
    $stmtU->execute([':m' => $matricula]);
    $usuario = $stmtU->fetch();
    if (!$usuario) {
        return null;
    }

    $placeholders = implode(',', array_fill(0, count($ids), '?'));
    $stmtA = $pdo->prepare(
        "SELECT id_actividad, descripcion FROM actividad WHERE id_actividad IN ($placeholders) ORDER BY id_actividad"
    );
    $stmtA->execute($ids);
    $actividades = $stmtA->fetchAll();

    return [
        'usuario' => $usuario,
        'actividades' => $actividades,
        'fecha_hora' => $datos['fecha_hora'] ?? date('Y-m-d H:i:s'),
    ];
}

function visitas_exito_por_matricula(PDO $pdo, string $matricula): ?array
{
    $stmt = $pdo->prepare(
        'SELECT vr.id_visita, vr.fecha_hora, a.descripcion
         FROM visita_registro vr
         INNER JOIN actividad a ON a.id_actividad = vr.id_actividad
         WHERE vr.matricula = :m
           AND vr.fecha_hora >= DATE_SUB(NOW(), INTERVAL 2 MINUTE)
         ORDER BY vr.id_visita'
    );
    $stmt->execute([':m' => $matricula]);
    $filas = $stmt->fetchAll();
    if (!$filas) {
        return null;
    }

    $stmtU = $pdo->prepare(
        'SELECT u.matricula, u.nombre, u.correo, u.grado, u.estatus,
                p.nombre AS programa
         FROM usuario u
         LEFT JOIN programa_educativo p ON p.id_programa = u.id_programa
         WHERE u.matricula = :m'
    );
    $stmtU->execute([':m' => $matricula]);
    $usuario = $stmtU->fetch();
    if (!$usuario) {
        return null;
    }

    return [
        'usuario' => $usuario,
        'actividades' => $filas,
        'fecha_hora' => $filas[0]['fecha_hora'],
    ];
}
