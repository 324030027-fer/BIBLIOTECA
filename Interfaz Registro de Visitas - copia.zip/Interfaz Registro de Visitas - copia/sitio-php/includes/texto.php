<?php

declare(strict_types=1);

/**
 * Funciones de texto compatibles sin extensión mbstring.
 * Si mbstring está instalada, se usa; si no, fallback con strlen/substr.
 */

function texto_len(string $texto): int
{
    return function_exists('mb_strlen')
        ? mb_strlen($texto, 'UTF-8')
        : strlen($texto);
}

function texto_substr(string $texto, int $inicio, ?int $longitud = null): string
{
    if (function_exists('mb_substr')) {
        return $longitud === null
            ? mb_substr($texto, $inicio, null, 'UTF-8')
            : mb_substr($texto, $inicio, $longitud, 'UTF-8');
    }

    return $longitud === null
        ? substr($texto, $inicio)
        : substr($texto, $inicio, $longitud);
}

function texto_upper(string $texto): string
{
    return function_exists('mb_strtoupper')
        ? mb_strtoupper($texto, 'UTF-8')
        : strtoupper($texto);
}

function texto_stripos(string $texto, string $buscar): int|false
{
    return function_exists('mb_stripos')
        ? mb_stripos($texto, $buscar, 0, 'UTF-8')
        : stripos($texto, $buscar);
}

/** @return list<string>|false */
function leer_fila_csv($handle): array|false
{
    return fgetcsv($handle, 0, ',', '"', '\\');
}
