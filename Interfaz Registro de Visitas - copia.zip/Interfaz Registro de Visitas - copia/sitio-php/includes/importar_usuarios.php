<?php

declare(strict_types=1);

require_once __DIR__ . '/texto.php';

/**
 * Importa usuarios desde el CSV oficial (matrículas 2503).
 * La columna id_programa del CSV trae códigos como "TSU IFI", no el ID numérico.
 */

function ruta_csv_usuarios(): string
{
    $candidatos = [
        __DIR__ . '/../datos/matriculas_2503.csv',
        dirname(__DIR__, 2) . '/matricula oficial_2503 (1).xlsx - LIC_2503.csv',
    ];

    foreach ($candidatos as $ruta) {
        if (is_readable($ruta)) {
            return $ruta;
        }
    }

    throw new RuntimeException(
        'No se encontró el CSV. Colócalo en sitio-php/datos/matriculas_2503.csv'
    );
}

function normalizar_sexo(?string $sexo): ?string
{
    $s = texto_upper(trim((string) $sexo));

    return match ($s) {
        'HOMBRE', 'H', 'M' => 'M',
        'MUJER', 'F' => 'F',
        default => null,
    };
}

function recortar(?string $valor, int $max): ?string
{
    $v = trim((string) $valor);
    if ($v === '') {
        return null;
    }

    return texto_len($v) > $max ? texto_substr($v, 0, $max) : $v;
}

/** @return list<array<string, string>> */
function leer_filas_csv_usuarios(?string $ruta = null): array
{
    $ruta = $ruta ?? ruta_csv_usuarios();
    $handle = fopen($ruta, 'rb');
    if ($handle === false) {
        throw new RuntimeException('No se pudo abrir el CSV: ' . $ruta);
    }

    $filas = [];
    $encabezados = null;

    while (($row = leer_fila_csv($handle)) !== false) {
        if ($encabezados === null) {
            if (isset($row[0])) {
                $row[0] = preg_replace('/^\xEF\xBB\xBF/', '', $row[0]) ?? $row[0];
            }
            $encabezados = array_map(static fn ($h) => trim((string) $h), $row);
            continue;
        }

        if (count(array_filter($row, static fn ($c) => trim((string) $c) !== '')) === 0) {
            continue;
        }

        $data = [];
        foreach ($encabezados as $i => $col) {
            $data[$col] = trim((string) ($row[$i] ?? ''));
        }

        if (($data['matricula'] ?? '') !== '') {
            $filas[] = $data;
        }
    }

    fclose($handle);

    return $filas;
}

function asegurar_programas(PDO $pdo, array $codigos): int
{
    $insert = $pdo->prepare('INSERT IGNORE INTO programa_educativo (nombre) VALUES (:nombre)');
    $n = 0;

    foreach ($codigos as $codigo) {
        $insert->execute([':nombre' => $codigo]);
        $n += $insert->rowCount();
    }

    return $n;
}

/** @return array<string, int> */
function mapa_programas(PDO $pdo): array
{
    $mapa = [];
    foreach ($pdo->query('SELECT id_programa, nombre FROM programa_educativo') as $fila) {
        $mapa[$fila['nombre']] = (int) $fila['id_programa'];
    }

    return $mapa;
}

/**
 * @return array{
 *   csv: string,
 *   filas_csv: int,
 *   programas_nuevos: int,
 *   insertados: int,
 *   actualizados: int,
 *   omitidos: int,
 *   errores: list<string>
 * }
 */
function importar_usuarios_desde_csv(PDO $pdo, ?string $ruta = null): array
{
    $ruta = $ruta ?? ruta_csv_usuarios();
    $filas = leer_filas_csv_usuarios($ruta);

    $codigos = [];
    foreach ($filas as $fila) {
        $cod = trim($fila['id_programa'] ?? '');
        if ($cod !== '') {
            $codigos[$cod] = true;
        }
    }

    $programasNuevos = asegurar_programas($pdo, array_keys($codigos));
    $mapaProgramas = mapa_programas($pdo);

    $sql = 'INSERT INTO usuario (matricula, nombre, correo, grado, sexo, estatus, tutor, id_programa)
            VALUES (:matricula, :nombre, :correo, :grado, :sexo, :estatus, :tutor, :id_programa)
            ON DUPLICATE KEY UPDATE
                nombre = VALUES(nombre),
                correo = VALUES(correo),
                grado = VALUES(grado),
                sexo = VALUES(sexo),
                estatus = VALUES(estatus),
                tutor = VALUES(tutor),
                id_programa = VALUES(id_programa)';

    $stmt = $pdo->prepare($sql);

    $insertados = 0;
    $actualizados = 0;
    $omitidos = 0;
    $errores = [];
    $vistos = [];

    $pdo->beginTransaction();

    try {
        foreach ($filas as $i => $fila) {
            $matricula = recortar($fila['matricula'] ?? '', 20);
            if ($matricula === null) {
                $omitidos++;
                continue;
            }

            if (isset($vistos[$matricula])) {
                $omitidos++;
                $errores[] = 'Fila ' . ($i + 2) . ': matrícula duplicada en CSV (' . $matricula . ')';
                continue;
            }
            $vistos[$matricula] = true;

            $codigoPrograma = trim($fila['id_programa'] ?? '');
            $idPrograma = $codigoPrograma !== '' && isset($mapaProgramas[$codigoPrograma])
                ? $mapaProgramas[$codigoPrograma]
                : null;

            if ($codigoPrograma !== '' && $idPrograma === null) {
                $errores[] = 'Fila ' . ($i + 2) . ': programa no encontrado (' . $codigoPrograma . ')';
            }

            $stmt->execute([
                ':matricula' => $matricula,
                ':nombre' => recortar($fila['nombre'] ?? '', 150) ?? $matricula,
                ':correo' => recortar($fila['correo'] ?? '', 100),
                ':grado' => recortar($fila['grado'] ?? '', 20),
                ':sexo' => normalizar_sexo($fila['sexo'] ?? null),
                ':estatus' => recortar($fila['estatus'] ?? '', 20),
                ':tutor' => recortar($fila['tutor'] ?? '', 150),
                ':id_programa' => $idPrograma,
            ]);

            if ($stmt->rowCount() === 1) {
                $insertados++;
            } elseif ($stmt->rowCount() === 2) {
                $actualizados++;
            }
        }

        $pdo->commit();
    } catch (Throwable $e) {
        $pdo->rollBack();
        throw $e;
    }

    return [
        'csv' => $ruta,
        'filas_csv' => count($filas),
        'programas_nuevos' => $programasNuevos,
        'insertados' => $insertados,
        'actualizados' => $actualizados,
        'omitidos' => $omitidos,
        'errores' => $errores,
    ];
}

function resumen_csv_usuarios(?string $ruta = null): array
{
    $ruta = $ruta ?? ruta_csv_usuarios();
    $filas = leer_filas_csv_usuarios($ruta);
    $programas = [];

    foreach ($filas as $fila) {
        $p = trim($fila['id_programa'] ?? '');
        if ($p !== '') {
            $programas[$p] = ($programas[$p] ?? 0) + 1;
        }
    }

    ksort($programas);

    return [
        'ruta' => $ruta,
        'total' => count($filas),
        'programas' => $programas,
    ];
}
