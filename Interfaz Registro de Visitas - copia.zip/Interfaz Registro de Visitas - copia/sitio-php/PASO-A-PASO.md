# Biblioteca UPJR — Sitio PHP + MySQL

Interfaz basada en tu diseño React (`Interfaz Registro de Visitas`), adaptada a **HTML + PHP + MySQL** sin Node ni XAMPP.

## Requisitos

- **MySQL** en ejecución con la base `biblioteca_upjr` y tus tablas
- **PHP 8+** con extensión `pdo_mysql`

## Configuración

1. Edita `config/config.php` con tu usuario y contraseña MySQL:

```php
'db_name' => 'biblioteca_upjr',
'db_user' => 'root',
'db_pass' => 'TU_CONTRASEÑA',
```

2. (Opcional) Si quieres probar visitas sin alumnos reales, ejecuta en MySQL:

- `sql/usuarios_ejemplo.sql`

## Levantar el sitio (sin XAMPP)

En PowerShell:

```powershell
cd "c:\Users\gutie\Downloads\Interfaz Registro de Visitas\sitio-php"
php -S localhost:8080
```

Abre: **http://localhost:8080**

## Pantallas

| Archivo | Función |
|---------|---------|
| `index.php` | Inicio con estadísticas reales (libros, usuarios, visitas del mes) |
| `catalogo-libros.php` | Buscar y analizar `libros_prueba` o `libro` |
| `registro-visita.php` | Buscar usuario y registrar actividades |
| `api/buscar.php` | JSON de usuarios (`usuario` + `programa_educativo`) |
| `api/libros.php` | JSON del catálogo con paginación |
| `acciones/registrar.php` | Inserta en `visita_registro` (una fila por actividad) |

## Tablas que usa el sitio

- **Libros:** `libros_prueba` o, si existe, `libro` (detecta automáticamente)
- **Visitas:** `usuario`, `actividad`, `visita_registro`
- Cada actividad marcada genera un registro en `visita_registro` con la misma `fecha_hora`

## Flujo de prueba

1. **Catálogo** → busca por título, autor, ISBN o estante
2. **Registrar visita** → busca matrícula o nombre (necesitas filas en `usuario`)
3. Marca actividades de la tabla `actividad` (TAREAS, CONSULTA DE LIBRO, etc.)
4. Confirma → se guarda en `visita_registro`

## Si no hay usuarios aún

El formulario de visitas ya está listo; solo verás el aviso hasta que insertes alumnos en `usuario`. El catálogo de libros funciona de inmediato si tienes datos en `libros_prueba`.

## Próximos pasos sugeridos

- Pantalla para alta de usuarios
- Reporte de visitas por día / por actividad
- Salida de biblioteca (hora de salida)
