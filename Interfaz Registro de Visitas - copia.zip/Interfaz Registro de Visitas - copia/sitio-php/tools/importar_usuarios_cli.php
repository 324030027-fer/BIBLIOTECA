<?php

declare(strict_types=1);

require_once dirname(__DIR__) . '/config/database.php';
require_once dirname(__DIR__) . '/includes/importar_usuarios.php';

if (PHP_SAPI !== 'cli') {
    fwrite(STDERR, "Ejecuta desde consola: php tools/importar_usuarios_cli.php\n");
    exit(1);
}

try {
    $pdo = db();
    try {
        $pdo->exec(
            'ALTER TABLE usuario
             MODIFY nombre VARCHAR(150) NOT NULL,
             MODIFY tutor VARCHAR(150) NULL'
        );
    } catch (Throwable) {
    }

    $res = importar_usuarios_desde_csv($pdo);
    echo "CSV: {$res['csv']}\n";
    echo "Filas: {$res['filas_csv']}\n";
    echo "Programas nuevos: {$res['programas_nuevos']}\n";
    echo "Insertados: {$res['insertados']}\n";
    echo "Actualizados: {$res['actualizados']}\n";
    echo "Omitidos: {$res['omitidos']}\n";
    if ($res['errores']) {
        echo "Avisos: " . count($res['errores']) . "\n";
    }
    exit(0);
} catch (Throwable $e) {
    fwrite(STDERR, 'Error: ' . $e->getMessage() . "\n");
    exit(1);
}
