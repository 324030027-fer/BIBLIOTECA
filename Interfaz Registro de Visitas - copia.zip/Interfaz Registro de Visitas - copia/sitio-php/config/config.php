<?php
/**
 * Configuración de conexión MySQL (sin XAMPP: solo PHP + MySQL).
 * Ajusta usuario y contraseña según tu instalación.
 */
return [
    'db_host' => '127.0.0.1',
    'db_name' => 'biblioteca_upjr',
    'db_user' => 'root',
    'db_pass' => 'UPJR*2026',
    'db_charset' => 'utf8mb4',
    'timezone' => 'America/Mexico_City',
];
