(function () {
  const input = document.getElementById('busqueda-libros');
  const box = document.getElementById('busqueda-libros-box');
  const btnLimpiar = document.getElementById('btn-limpiar-libros');
  const cuerpo = document.getElementById('cuerpo-libros');
  const paginacion = document.getElementById('paginacion');

  if (!input || !cuerpo) return;

  let pagina = 1;
  let timer = null;
  const tieneClase = window.CATALOGO_TABLA === 'libros_prueba';
  const cols = tieneClase ? 9 : 8;

  function esc(v) {
    if (v === null || v === undefined || v === '') return '—';
    const d = document.createElement('div');
    d.textContent = String(v);
    return d.innerHTML;
  }

  async function cargar() {
    const q = input.value.trim();
    cuerpo.innerHTML = `<tr><td colspan="${cols}" class="cargando">Buscando...</td></tr>`;

    try {
      const url = `api/libros.php?q=${encodeURIComponent(q)}&pagina=${pagina}`;
      const res = await fetch(url);
      const data = await res.json();
      renderTabla(data.libros || []);
      renderPaginacion(data.total, data.pagina, data.por_pagina);
    } catch (e) {
      cuerpo.innerHTML = `<tr><td colspan="${cols}" class="cargando" style="color:#b91c1c;">Error al cargar libros</td></tr>`;
    }
  }

  function renderTabla(libros) {
    if (!libros.length) {
      cuerpo.innerHTML = `<tr><td colspan="${cols}" class="cargando">No se encontraron libros</td></tr>`;
      return;
    }

    cuerpo.innerHTML = libros
      .map((l) => {
        let fila = `<tr>
          <td><strong>${esc(l.titulo)}</strong></td>
          <td>${esc(l.autor)}</td>
          <td>${esc(l.isbn)}</td>
          <td>${esc(l.editorial)}</td>
          <td>${esc(l.anio_publicacion)}</td>
          <td>${esc(l.estante)}</td>
          <td>${esc(l.repisa)}</td>
          <td class="num">${esc(l.copias)}</td>`;
        if (tieneClase) {
          fila += `<td>${esc(l.clase)}</td>`;
        }
        fila += '</tr>';
        return fila;
      })
      .join('');
  }

  function renderPaginacion(total, pagActual, porPagina) {
    const totalPag = Math.max(1, Math.ceil(total / porPagina));
    paginacion.innerHTML = '';

    if (totalPag <= 1) return;

    const info = document.createElement('span');
    info.className = 'pag-info';
    info.textContent = `Página ${pagActual} de ${totalPag} · ${total} títulos`;
    paginacion.appendChild(info);

    const prev = document.createElement('button');
    prev.type = 'button';
    prev.textContent = 'Anterior';
    prev.disabled = pagActual <= 1;
    prev.addEventListener('click', () => {
      pagina = pagActual - 1;
      cargar();
    });

    const next = document.createElement('button');
    next.type = 'button';
    next.textContent = 'Siguiente';
    next.disabled = pagActual >= totalPag;
    next.addEventListener('click', () => {
      pagina = pagActual + 1;
      cargar();
    });

    paginacion.appendChild(prev);
    paginacion.appendChild(next);
  }

  input.addEventListener('input', () => {
    btnLimpiar.classList.toggle('hidden', input.value.trim() === '');
    pagina = 1;
    clearTimeout(timer);
    timer = setTimeout(cargar, 300);
  });

  input.addEventListener('focus', () => box?.classList.add('focus'));
  input.addEventListener('blur', () => box?.classList.remove('focus'));

  btnLimpiar?.addEventListener('click', () => {
    input.value = '';
    btnLimpiar.classList.add('hidden');
    pagina = 1;
    cargar();
    input.focus();
  });

  cargar();
})();
