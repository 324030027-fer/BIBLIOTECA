# Guía paso a paso — Desde cero (tu situación actual)

## Lo que YA tienes en MySQL

- Base de datos `biblioteca_upjr`
- Tabla `libros_prueba` (libros)
- Tabla `programa_educativo` (1 programa: Administración)
- Tabla `actividad` (5 actividades)

## Lo que te FALTA

- Tabla `usuario` ← alumnos del CSV
- Tabla `visita_registro` ← guardar visitas
- Cargar los ~1.234 usuarios del CSV

---

## PASO 1 — Crear las tablas que faltan

1. Abre **MySQL Workbench** (o tu cliente MySQL).
2. Conéctate a tu servidor.
3. Abre el archivo:
   ```
   sitio-php/sql/crear_tablas_faltantes.sql
   ```
4. Ejecuta todo el script (⚡ Execute).

Debes ver las tablas `usuario` y `visita_registro` en `biblioteca_upjr`.

---

## PASO 2 — Configurar PHP (si no lo hiciste)

Edita `sitio-php/config/config.php`:

```php
'db_name' => 'biblioteca_upjr',
'db_user' => 'root',
'db_pass' => 'TU_CONTRASEÑA',   // vacío '' si no tienes contraseña
```

---

## PASO 3 — Levantar el sitio

En PowerShell:

```powershell
cd "c:\Users\gutie\Downloads\Interfaz Registro de Visitas\sitio-php"
php -S localhost:8080
```

Abre: **http://localhost:8080**

Debes ver la pantalla de inicio sin error de conexión.

---

## PASO 4 — Importar usuarios del CSV

1. Confirma que el CSV está aquí:
   ```
   Interfaz Registro de Visitas\matricula oficial_2503 (1).xlsx - LIC_2503.csv
   ```
2. Ve a: **http://localhost:8080/importar-usuarios.php**
3. Debe mostrar ~1.234 registros del CSV.
4. Clic en **Importar usuarios a MySQL**.

Esto hace dos cosas:
- Crea programas nuevos en `programa_educativo` (TSU IFI, LAG, IFI, etc.)
- Inserta todos los alumnos en `usuario`

---

## PASO 5 — Verificar que los usuarios entraron

**Opción A — En el navegador:**  
http://localhost:8080/usuarios.php

**Opción B — En MySQL:**

```sql
USE biblioteca_upjr;
SELECT COUNT(*) FROM usuario;
SELECT * FROM usuario LIMIT 5;
SELECT * FROM programa_educativo;
```

Debes ver cientos/miles de usuarios y varios programas (no solo Administración).

---

## PASO 6 — Probar catálogo de libros

http://localhost:8080/catalogo-libros.php

Busca un título o autor. Usa tu tabla `libros_prueba`.

---

## PASO 7 — Probar registro de visitas

1. http://localhost:8080/registro-visita.php
2. Busca un alumno (nombre o matrícula, ej. `325030308`).
3. Selecciónalo.
4. Marca una o más actividades (TAREAS, CONSULTA DE LIBRO, etc.).
5. **Confirmar Registro de Visita**.

**Verificar en MySQL:**

```sql
SELECT vr.*, u.nombre, a.descripcion
FROM visita_registro vr
JOIN usuario u ON u.matricula = vr.matricula
JOIN actividad a ON a.id_actividad = vr.id_actividad
ORDER BY vr.fecha_hora DESC
LIMIT 10;
```

---

## Resumen visual

```
MySQL (lo que ya tienes)
├── libros_prueba     ✅
├── programa_educativo ✅
└── actividad         ✅

MySQL (PASO 1 - crear)
├── usuario           ← crear_tablas_faltantes.sql
└── visita_registro   ← crear_tablas_faltantes.sql

MySQL (PASO 4 - importar CSV)
└── usuario           ← ~1.234 alumnos
    programa_educativo ← programas del CSV

Sitio PHP
├── Catálogo libros   → libros_prueba
├── Importar usuarios → CSV → usuario
└── Registro visita   → usuario + actividad → visita_registro
```

---

## Si algo falla

| Error | Qué hacer |
|-------|-----------|
| "No hay conexión a MySQL" | Revisa `config/config.php` y que MySQL esté encendido |
| "Table 'usuario' doesn't exist" | Ejecuta `crear_tablas_faltantes.sql` (PASO 1) |
| "No se encontró el CSV" | Deja el CSV en la carpeta del proyecto o copia a `sitio-php/datos/matriculas_2503.csv` |
| "Call to undefined function mb_strlen" | Ya corregido en el código. Recarga la página o reinicia `php -S` |
| "Usuario no encontrado" al registrar visita | Importa el CSV primero (PASO 4) |

---

## Después de esto (más adelante)

- Tabla `libro` normalizada (opcional, ya tienes `libros_prueba`)
- Tabla `prestamo` (préstamos de libros)
- Reporte de visitas del día

Por ahora con los 7 pasos de arriba ya puedes usar **libros + usuarios + registro de actividades**.
