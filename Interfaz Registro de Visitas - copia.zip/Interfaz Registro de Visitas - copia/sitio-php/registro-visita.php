<?php

declare(strict_types=1);

session_start();

require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/includes/funciones.php';

$pdo = null;
$catalogo = [];
$error = $_SESSION['error'] ?? null;
unset($_SESSION['error']);
$sinUsuarios = false;

try {
    $pdo = db();
    $catalogo = actividades_desde_bd($pdo);
    if ($pdo->query('SELECT COUNT(*) FROM usuario')->fetchColumn() == 0) {
        $sinUsuarios = true;
    }
} catch (Throwable $e) {
    $error = $error ?: 'No se pudo conectar a la base de datos: ' . $e->getMessage();
}

$visitaExito = null;
if ($pdo && isset($_GET['exito'])) {
    try {
        if (isset($_SESSION['visita_exito'])) {
            $visitaExito = visitas_exito_desde_sesion($pdo, $_SESSION['visita_exito']);
            unset($_SESSION['visita_exito']);
        } elseif (isset($_GET['matricula'])) {
            $visitaExito = visitas_exito_por_matricula($pdo, trim((string) $_GET['matricula']));
        }
    } catch (Throwable) {
        $visitaExito = null;
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registro de Visita · Biblioteca UPJR</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="assets/css/estilos.css">
</head>
<body class="page-registro">
    <header class="header-registro">
        <div class="header-inner">
            <a href="index.php" class="btn-volver">
                <i class="fa-solid fa-chevron-left"></i> Inicio
            </a>
            <div class="header-center">
                <h2 style="color:#fff;font-size:1.1rem;font-weight:700;">Registro de Visita</h2>
                <p style="color:rgba(255,255,255,.5);font-size:.75rem;">Biblioteca · UPJR</p>
            </div>
            <div class="header-right">
                <div style="color:#fff;font-family:monospace;font-weight:600;" id="reloj">--:--</div>
                <p style="color:rgba(255,255,255,.5);font-size:.7rem;text-transform:capitalize;" id="fecha"><?= h(fecha_larga_es()) ?></p>
            </div>
        </div>
    </header>

    <main class="main-registro">
        <?php if ($error): ?>
            <p class="msg-error"><?= h($error) ?></p>
        <?php endif; ?>

        <?php if ($sinUsuarios && !$visitaExito): ?>
            <p class="msg-aviso">
                <i class="fa-solid fa-circle-info"></i>
                No hay usuarios cargados en la base de datos. Contacta al administrador del sistema.
            </p>
        <?php endif; ?>

        <?php if ($visitaExito): ?>
            <?php $u = $visitaExito['usuario']; ?>
            <section class="exito-card">
                <div class="exito-icon"><i class="fa-solid fa-circle-check"></i></div>
                <h2 style="color:#fff;font-size:1.5rem;font-weight:800;margin-bottom:.5rem;">¡Visita Registrada!</h2>
                <p style="color:rgba(255,255,255,.6);font-size:.875rem;margin-bottom:1.5rem;">
                    El acceso de <strong style="color:#fff"><?= h($u['nombre']) ?></strong>
                    (<?= h($u['matricula']) ?>) ha sido registrado.
                </p>
                <div class="exito-lista">
                    <p style="color:rgba(255,255,255,.5);font-size:.7rem;text-transform:uppercase;margin-bottom:.5rem;">Actividades registradas</p>
                    <ul>
                        <?php foreach ($visitaExito['actividades'] as $act): ?>
                            <li>
                                <i class="fa-solid fa-check" style="color:#4198C6;margin-right:.5rem;"></i>
                                <?= h($act['descripcion'] ?? '') ?>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                    <p style="color:rgba(255,255,255,.6);font-size:.75rem;margin-top:.75rem;padding-top:.75rem;border-top:1px solid rgba(255,255,255,.1);">
                        <i class="fa-solid fa-clock" style="color:#F97316;"></i>
                        Hora: <?= h(date('H:i', strtotime($visitaExito['fecha_hora']))) ?>
                        · <?= h(date('d/m/Y', strtotime($visitaExito['fecha_hora']))) ?>
                    </p>
                </div>
                <div class="exito-btns">
                    <a href="registro-visita.php" class="btn-confirmar" style="display:inline-block;text-align:center;">Nueva Visita</a>
                    <a href="index.php" class="btn-outline-exito">Ir al Inicio</a>
                </div>
            </section>
        <?php elseif (count($catalogo) === 0): ?>
            <p class="msg-error">No hay actividades en la tabla <code>actividad</code>. Ejecuta los INSERT de tu script SQL.</p>
        <?php else: ?>

            <div class="titulo-busqueda">
                <h1>Busca al <span>Visitante</span></h1>
                <p>Ingresa nombre, matrícula o correo del usuario</p>
            </div>

            <div class="busqueda-wrap">
                <div class="busqueda-box" id="busqueda-box">
                    <i class="fa-solid fa-magnifying-glass" style="color:#4198C6;"></i>
                    <input type="text" id="busqueda-input" placeholder="Buscar por nombre o matrícula..." autocomplete="off">
                    <button type="button" id="btn-limpiar" class="hidden" style="color:#9ca3af;"><i class="fa-solid fa-xmark"></i></button>
                </div>
                <div class="dropdown" id="dropdown"></div>
            </div>

            <p class="empty-hint" id="hint-vacio">
                <i class="fa-solid fa-magnifying-glass"></i>
                Escribe al menos 2 caracteres para buscar un usuario
            </p>

            <section id="panel-registro" class="hidden">
                <div class="tarjeta-usuario" id="tarjeta-usuario"></div>

                <form class="tarjeta-form" method="post" action="acciones/registrar.php" id="form-visita">
                    <input type="hidden" name="matricula" id="matricula" value="">

                    <h3 style="font-weight:700;color:#1f2937;margin-bottom:.25rem;">Actividad a realizar</h3>
                    <p style="color:#9ca3af;font-size:.75rem;margin-bottom:1rem;">Selecciona una o más actividades (requerido)</p>

                    <div class="actividades-grid">
                        <?php foreach ($catalogo as $id => $label): ?>
                            <label class="actividad-btn" data-id="<?= (int) $id ?>">
                                <input type="checkbox" name="actividades[]" value="<?= (int) $id ?>">
                                <span class="act-icon-wrap">
                                    <i class="fa-solid <?= h(icono_actividad($label)) ?>" style="color:#4198C6;"></i>
                                </span>
                                <span class="act-label"><?= h($label) ?></span>
                            </label>
                        <?php endforeach; ?>
                    </div>

                    <div class="info-hora">
                        <i class="fa-solid fa-clock"></i>
                        <span>La visita se registrará con hora: <strong id="hora-registro"><?= h(hora_actual()) ?></strong> · <?= h(fecha_larga_es()) ?></span>
                    </div>

                    <button type="submit" class="btn-confirmar" id="btn-registrar" disabled>
                        Selecciona al menos una actividad
                    </button>
                </form>
            </section>
        <?php endif; ?>
    </main>

    <script src="assets/js/registro.js"></script>
</body>
</html>
