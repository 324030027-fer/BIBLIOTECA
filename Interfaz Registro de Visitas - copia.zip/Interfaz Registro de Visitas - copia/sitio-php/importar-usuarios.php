<?php

declare(strict_types=1);

require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/includes/funciones.php';
require_once __DIR__ . '/includes/importar_usuarios.php';

$resultado = null;
$error = null;
$resumen = null;

try {
    $resumen = resumen_csv_usuarios();
} catch (Throwable $e) {
    $error = $e->getMessage();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['importar'])) {
    try {
        $pdo = db();
        $pdo->exec(
            'ALTER TABLE usuario
             MODIFY nombre VARCHAR(150) NOT NULL,
             MODIFY tutor VARCHAR(150) NULL'
        );
    } catch (Throwable) {
        // La tabla ya puede tener esos tamaños.
    }

    try {
        $resultado = importar_usuarios_desde_csv(db());
        $resumen = resumen_csv_usuarios();
    } catch (Throwable $e) {
        $error = $e->getMessage();
    }
}

$totalBd = 0;
try {
    $totalBd = (int) db()->query('SELECT COUNT(*) FROM usuario')->fetchColumn();
} catch (Throwable) {
    // Sin conexión o sin tabla.
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Importar usuarios · Biblioteca UPJR</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="assets/css/estilos.css">
</head>
<body class="page-registro">
    <header class="header-registro">
        <div class="header-inner">
            <a href="index.php" class="btn-volver"><i class="fa-solid fa-chevron-left"></i> Inicio</a>
            <div class="header-center">
                <h2 style="color:#fff;font-size:1.1rem;font-weight:700;">Importar usuarios</h2>
                <p style="color:rgba(255,255,255,.5);font-size:.75rem;">CSV matrículas 2503</p>
            </div>
            <a href="usuarios.php" class="btn-volver">Ver usuarios</a>
        </div>
    </header>

    <main class="main-registro catalogo-main">
        <?php if ($error): ?>
            <p class="msg-error"><?= h($error) ?></p>
        <?php endif; ?>

        <?php if ($resultado): ?>
            <div class="import-ok">
                <h3><i class="fa-solid fa-circle-check"></i> Importación completada</h3>
                <ul>
                    <li>Filas en CSV: <strong><?= (int) $resultado['filas_csv'] ?></strong></li>
                    <li>Programas nuevos: <strong><?= (int) $resultado['programas_nuevos'] ?></strong></li>
                    <li>Usuarios insertados: <strong><?= (int) $resultado['insertados'] ?></strong></li>
                    <li>Usuarios actualizados: <strong><?= (int) $resultado['actualizados'] ?></strong></li>
                    <li>Omitidos: <strong><?= (int) $resultado['omitidos'] ?></strong></li>
                </ul>
                <?php if ($resultado['errores']): ?>
                    <details class="import-errores">
                        <summary><?= count($resultado['errores']) ?> avisos</summary>
                        <ul>
                            <?php foreach (array_slice($resultado['errores'], 0, 20) as $aviso): ?>
                                <li><?= h($aviso) ?></li>
                            <?php endforeach; ?>
                        </ul>
                    </details>
                <?php endif; ?>
                <p style="margin-top:1rem;">
                    <a href="registro-visita.php" class="btn-principal" style="display:inline-flex;padding:.75rem 1.25rem;">
                        Probar registro de visita
                    </a>
                </p>
            </div>
        <?php endif; ?>

        <div class="tarjeta-form" style="max-width:40rem;margin:0 auto 1.5rem;">
            <h3 style="font-weight:700;color:#0a1f2e;margin-bottom:.5rem;">Estado actual</h3>
            <p style="color:#6b7280;font-size:.875rem;margin-bottom:1rem;">
                Usuarios en MySQL: <strong><?= number_format($totalBd) ?></strong>
            </p>

            <?php if ($resumen): ?>
                <p style="color:#6b7280;font-size:.875rem;margin-bottom:.5rem;">
                    Archivo CSV: <code style="font-size:.75rem;"><?= h(basename($resumen['ruta'])) ?></code>
                </p>
                <p style="color:#6b7280;font-size:.875rem;margin-bottom:1rem;">
                    Registros en CSV: <strong><?= number_format($resumen['total']) ?></strong>
                    · Programas distintos: <strong><?= count($resumen['programas']) ?></strong>
                </p>

                <details style="margin-bottom:1.25rem;">
                    <summary style="cursor:pointer;color:#4198C6;font-weight:600;">Ver programas del CSV</summary>
                    <ul class="lista-programas">
                        <?php foreach ($resumen['programas'] as $nombre => $cant): ?>
                            <li><span><?= h($nombre) ?></span> <em><?= $cant ?> alumnos</em></li>
                        <?php endforeach; ?>
                    </ul>
                </details>
            <?php endif; ?>

            <form method="post" onsubmit="return confirm('¿Importar o actualizar todos los usuarios del CSV?');">
                <button type="submit" name="importar" value="1" class="btn-confirmar" <?= $resumen ? '' : 'disabled' ?>>
                    <i class="fa-solid fa-file-import"></i>
                    Importar usuarios a MySQL
                </button>
            </form>

            <p style="color:#9ca3af;font-size:.75rem;margin-top:1rem;">
                Crea los programas educativos del CSV y carga la tabla <code>usuario</code>.
                Si vuelves a importar, los registros existentes se actualizan por matrícula.
            </p>
        </div>

        <div class="tarjeta-form" style="max-width:40rem;margin:0 auto;">
            <h3 style="font-weight:700;color:#0a1f2e;margin-bottom:.75rem;">Pasos recomendados</h3>
            <ol class="pasos-lista">
                <li>Ejecuta en MySQL: <code>sql/ajustes_usuarios.sql</code> (opcional, el importador también ajusta).</li>
                <li>Confirma que el CSV esté en la carpeta del proyecto o en <code>sitio-php/datos/matriculas_2503.csv</code>.</li>
                <li>Pulsa <strong>Importar usuarios a MySQL</strong>.</li>
                <li>Ve a <a href="registro-visita.php">Registro de visita</a> y busca por matrícula o nombre.</li>
            </ol>
        </div>
    </main>
</body>
</html>
