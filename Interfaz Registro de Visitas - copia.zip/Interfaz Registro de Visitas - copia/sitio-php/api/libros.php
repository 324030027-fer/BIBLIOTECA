<?php

declare(strict_types=1);

header('Content-Type: application/json; charset=utf-8');

require_once dirname(__DIR__) . '/config/database.php';
require_once dirname(__DIR__) . '/includes/funciones.php';

$q = trim((string) ($_GET['q'] ?? ''));
$pagina = max(1, (int) ($_GET['pagina'] ?? 1));
$porPagina = 20;
$offset = ($pagina - 1) * $porPagina;

$pdo = db();
$tabla = fuente_libros($pdo);

if ($tabla === 'libro') {
    $sqlBase = 'FROM libro WHERE 1=1';
    $cols = 'isbn, titulo, autor, editorial, edicion, anio_publicacion,
             estante, repisa, total_copias AS copias, NULL AS clase';
} else {
    $sqlBase = 'FROM libros_prueba WHERE titulo IS NOT NULL AND TRIM(titulo) != \'\'';
    $cols = 'isbn, titulo, autor, editorial, edicion, anio_publicacion,
             Estante AS estante, Repisa AS repisa, copias, Clase AS clase';
}

$params = [];
if ($q !== '') {
    $sqlBase .= ' AND (
        titulo LIKE :q OR autor LIKE :q OR isbn LIKE :q
        OR editorial LIKE :q OR estante LIKE :q OR repisa LIKE :q
    )';
    $params[':q'] = '%' . $q . '%';
}

$stmtCount = $pdo->prepare("SELECT COUNT(*) $sqlBase");
$stmtCount->execute($params);
$total = (int) $stmtCount->fetchColumn();

$sql = "SELECT $cols $sqlBase ORDER BY titulo LIMIT $porPagina OFFSET $offset";
$stmt = $pdo->prepare($sql);
$stmt->execute($params);

echo json_encode([
    'tabla' => $tabla,
    'total' => $total,
    'pagina' => $pagina,
    'por_pagina' => $porPagina,
    'libros' => $stmt->fetchAll(),
], JSON_UNESCAPED_UNICODE);
