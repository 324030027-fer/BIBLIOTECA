<?php

declare(strict_types=1);

header('Content-Type: application/json; charset=utf-8');

require_once dirname(__DIR__) . '/config/database.php';
require_once dirname(__DIR__) . '/includes/funciones.php';

require_once dirname(__DIR__) . '/includes/texto.php';

$q = trim((string) ($_GET['q'] ?? ''));

if (texto_len($q) < 2) {
    echo json_encode([]);
    exit;
}

$pdo = db();
$like = '%' . $q . '%';

$stmt = $pdo->prepare(
    'SELECT u.matricula, u.nombre, u.correo, u.grado, u.estatus,
            p.nombre AS programa
     FROM usuario u
     LEFT JOIN programa_educativo p ON p.id_programa = u.id_programa
     WHERE u.nombre LIKE :q
        OR u.matricula LIKE :q
        OR u.correo LIKE :q
        OR p.nombre LIKE :q
     ORDER BY u.nombre
     LIMIT 15'
);
$stmt->execute([':q' => $like]);

$resultado = [];
foreach ($stmt->fetchAll() as $fila) {
    $resultado[] = [
        'matricula' => $fila['matricula'],
        'nombre' => $fila['nombre'],
        'correo' => $fila['correo'],
        'grado' => $fila['grado'],
        'estatus' => $fila['estatus'],
        'programa' => $fila['programa'],
        'tipo' => tipo_usuario($fila['matricula'], $fila['estatus']),
        'iniciales' => iniciales_nombre($fila['nombre']),
    ];
}

echo json_encode($resultado, JSON_UNESCAPED_UNICODE);
