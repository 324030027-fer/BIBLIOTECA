# Importar usuarios desde CSV (matrículas 2503)

Tu CSV tiene **~1.234 alumnos** con estas columnas:

`matricula, nombre, correo, grado, sexo, estatus, tutor, id_programa`

> **Nota:** La columna `id_programa` del Excel trae **códigos de carrera** (ej. `TSU IFI`, `LAG`, `IFI`), no el número de la base de datos. El importador crea esos programas en `programa_educativo` y luego enlaza cada usuario.

## Paso 1 — Ajuste opcional en MySQL

Ejecuta en MySQL Workbench o consola:

```sql
SOURCE ruta/a/sitio-php/sql/ajustes_usuarios.sql;
```

Amplía `nombre` y `tutor` a 150 caracteres (nombres largos en el CSV).

## Paso 2 — Verifica el CSV

El archivo debe estar en una de estas rutas:

- `Interfaz Registro de Visitas/matricula oficial_2503 (1).xlsx - LIC_2503.csv` (ya lo tienes)
- o copiado como `sitio-php/datos/matriculas_2503.csv`

## Paso 3 — Importar (elige una opción)

### Opción A — Desde el navegador (recomendada)

1. Levanta el sitio:
   ```powershell
   cd "c:\Users\gutie\Downloads\Interfaz Registro de Visitas\sitio-php"
   php -S localhost:8080
   ```
2. Abre **http://localhost:8080/importar-usuarios.php**
3. Revisa el resumen (total de filas y programas).
4. Clic en **Importar usuarios a MySQL**.

### Opción B — Desde consola

```powershell
cd "c:\Users\gutie\Downloads\Interfaz Registro de Visitas\sitio-php"
php tools/importar_usuarios_cli.php
```

## Paso 4 — Verificar

1. **http://localhost:8080/usuarios.php** — listado con búsqueda.
2. **http://localhost:8080/registro-visita.php** — busca por matrícula (ej. `325030308`) o nombre.
3. En MySQL:
   ```sql
   SELECT COUNT(*) FROM usuario;
   SELECT * FROM programa_educativo;
   SELECT * FROM usuario LIMIT 5;
   ```

## Paso 5 — Probar registro de visitas

1. Busca un alumno importado.
2. Marca actividades (TAREAS, CONSULTA DE LIBRO, etc.).
3. Confirma y revisa:
   ```sql
   SELECT * FROM visita_registro ORDER BY fecha_hora DESC LIMIT 10;
   ```

## Qué hace el importador

| Acción | Detalle |
|--------|---------|
| Programas | Inserta códigos únicos del CSV en `programa_educativo` |
| Usuarios | Inserta en `usuario` con FK al programa |
| Sexo | `HOMBRE` → `M`, `MUJER` → `F` |
| Reimportar | Si la matrícula ya existe, **actualiza** los datos |

## Archivos nuevos

```
sitio-php/
├── importar-usuarios.php      ← pantalla de importación
├── usuarios.php               ← consulta de usuarios
├── includes/importar_usuarios.php
├── tools/importar_usuarios_cli.php
├── sql/ajustes_usuarios.sql
└── datos/matriculas_2503.csv  ← opcional (copia del CSV)
```

## Siguiente paso después de importar

- Probar **registro de visitas** con alumnos reales.
- (Futuro) Reporte de visitas del día.
- (Futuro) Alta manual de un usuario sin CSV.
