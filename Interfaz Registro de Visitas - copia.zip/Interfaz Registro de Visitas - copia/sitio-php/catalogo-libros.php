<?php

declare(strict_types=1);

require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/includes/funciones.php';

$tabla = 'libros_prueba';
$total = 0;
$copias = 0;
$dbOk = true;
$error = '';

try {
    $pdo = db();
    $tabla = fuente_libros($pdo);
    if ($tabla === 'libro') {
        $total = (int) $pdo->query('SELECT COUNT(*) FROM libro')->fetchColumn();
        $copias = (int) $pdo->query('SELECT COALESCE(SUM(total_copias),0) FROM libro')->fetchColumn();
    } else {
        $total = (int) $pdo->query(
            "SELECT COUNT(*) FROM libros_prueba WHERE titulo IS NOT NULL AND TRIM(titulo) != ''"
        )->fetchColumn();
        $copias = (int) $pdo->query('SELECT COALESCE(SUM(copias),0) FROM libros_prueba')->fetchColumn();
    }
} catch (Throwable $e) {
    $dbOk = false;
    $error = $e->getMessage();
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Catálogo de Libros · Biblioteca UPJR</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="assets/css/estilos.css">
</head>
<body class="page-registro">
    <header class="header-registro">
        <div class="header-inner">
            <a href="index.php" class="btn-volver"><i class="fa-solid fa-chevron-left"></i> Inicio</a>
            <div class="header-center">
                <h2 style="color:#fff;font-size:1.1rem;font-weight:700;">Catálogo de Libros</h2>
                <p style="color:rgba(255,255,255,.5);font-size:.75rem;">Tabla: <?= h($tabla) ?></p>
            </div>
            <a href="registro-visita.php" class="btn-volver" style="margin-left:auto;">
                <i class="fa-solid fa-user-plus"></i> Registrar visita
            </a>
        </div>
    </header>

    <main class="main-registro catalogo-main">
        <?php if (!$dbOk): ?>
            <p class="msg-error"><?= h($error) ?></p>
        <?php else: ?>
            <div class="resumen-libros">
                <div class="resumen-item">
                    <span class="resumen-val"><?= number_format($total) ?></span>
                    <span class="resumen-lbl">Títulos</span>
                </div>
                <div class="resumen-item">
                    <span class="resumen-val"><?= number_format($copias) ?></span>
                    <span class="resumen-lbl">Copias</span>
                </div>
                <div class="resumen-item">
                    <span class="resumen-val"><?= h($tabla) ?></span>
                    <span class="resumen-lbl">Fuente MySQL</span>
                </div>
            </div>

            <div class="busqueda-wrap" style="margin-bottom:1.5rem;">
                <div class="busqueda-box" id="busqueda-libros-box">
                    <i class="fa-solid fa-magnifying-glass" style="color:#4198C6;"></i>
                    <input type="text" id="busqueda-libros" placeholder="Buscar por título, autor, ISBN, estante..." autocomplete="off">
                    <button type="button" id="btn-limpiar-libros" class="hidden" style="color:#9ca3af;"><i class="fa-solid fa-xmark"></i></button>
                </div>
            </div>

            <div class="tabla-wrap">
                <table class="tabla-libros" id="tabla-libros">
                    <thead>
                        <tr>
                            <th>Título</th>
                            <th>Autor</th>
                            <th>ISBN</th>
                            <th>Editorial</th>
                            <th>Año</th>
                            <th>Estante</th>
                            <th>Repisa</th>
                            <th>Copias</th>
                            <?php if ($tabla === 'libros_prueba'): ?><th>Clase</th><?php endif; ?>
                        </tr>
                    </thead>
                    <tbody id="cuerpo-libros">
                        <tr><td colspan="9" class="cargando">Cargando catálogo...</td></tr>
                    </tbody>
                </table>
            </div>

            <div class="paginacion" id="paginacion"></div>
        <?php endif; ?>
    </main>

    <script>
        window.CATALOGO_TABLA = <?= json_encode($tabla) ?>;
    </script>
    <script src="assets/js/libros.js"></script>
</body>
</html>
